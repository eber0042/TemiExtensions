//[sdk](../../../../index.md)/[com.robotemi.sdk.activitystream](../../index.md)/[ActivityStreamListItem](../index.md)/[Builder](index.md)/[mediaUrl](media-url.md)

# mediaUrl

[androidJvm]\
open fun [mediaUrl](media-url.md)(@NonNullmediaUrl: [String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html)): [ActivityStreamListItem.Builder](index.md)
