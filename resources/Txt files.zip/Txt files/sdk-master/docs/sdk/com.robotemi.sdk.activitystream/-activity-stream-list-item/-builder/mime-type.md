//[sdk](../../../../index.md)/[com.robotemi.sdk.activitystream](../../index.md)/[ActivityStreamListItem](../index.md)/[Builder](index.md)/[mimeType](mime-type.md)

# mimeType

[androidJvm]\
open fun [mimeType](mime-type.md)(@NonNullmimeType: [MediaObject.MimeType](../../../com.robotemi.sdk/-media-object/-mime-type/index.md)): [ActivityStreamListItem.Builder](index.md)
