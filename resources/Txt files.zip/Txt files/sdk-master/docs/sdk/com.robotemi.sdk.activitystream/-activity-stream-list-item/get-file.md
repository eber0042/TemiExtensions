[sdk](../../index.md) / [com.robotemi.sdk.activitystream](../index.md) / [ActivityStreamListItem](index.md) / [getFile](./get-file.md)

# getFile

`@Nullable open fun getFile(): `[`File`](https://developer.android.com/reference/java/io/File.html)`?`