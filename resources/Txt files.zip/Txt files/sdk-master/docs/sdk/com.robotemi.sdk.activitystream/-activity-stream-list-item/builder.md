//[sdk](../../../index.md)/[com.robotemi.sdk.activitystream](../index.md)/[ActivityStreamListItem](index.md)/[builder](builder.md)

# builder

[androidJvm]\
open fun [builder](builder.md)(): [ActivityStreamListItem.Builder](-builder/index.md)
