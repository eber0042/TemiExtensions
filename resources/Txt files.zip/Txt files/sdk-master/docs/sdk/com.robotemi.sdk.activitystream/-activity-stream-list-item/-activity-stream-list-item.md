//[sdk](../../../index.md)/[com.robotemi.sdk.activitystream](../index.md)/[ActivityStreamListItem](index.md)/[ActivityStreamListItem](-activity-stream-list-item.md)

# ActivityStreamListItem

[androidJvm]\
open fun [ActivityStreamListItem](-activity-stream-list-item.md)(@NonNulltitle: [String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html), @NonNullmessage: [String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html), @NonNullfile: [File](https://docs.oracle.com/javase/8/docs/api/java/io/File.html), @Nullableurl: [String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html), @Nullabledate: [String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html), @NullablemimeType: [MediaObject.MimeType](../../com.robotemi.sdk/-media-object/-mime-type/index.md))
