[sdk](../../index.md) / [com.robotemi.sdk.activitystream](../index.md) / [ActivityStreamListItem](index.md) / [getMediaUri](./get-media-uri.md)

# getMediaUri

`@Nullable open fun getMediaUri(): `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`?`

Overrides [MediaContainer.getMediaUri](../../com.robotemi.sdk/-media-container/get-media-uri.md)

