//[sdk](../../../index.md)/[com.robotemi.sdk.activitystream](../index.md)/[ActivityStreamListItem](index.md)/[message](message.md)

# message

[androidJvm]\

@Expose

@SerializedName(value = &quot;message&quot;)

@get:NonNull

open val [message](message.md): [String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html)
