//[sdk](../../../../index.md)/[com.robotemi.sdk.activitystream](../../index.md)/[ActivityStreamListItem](../index.md)/[Builder](index.md)/[build](build.md)

# build

[androidJvm]\
open fun [build](build.md)(): [ActivityStreamListItem](../index.md)
