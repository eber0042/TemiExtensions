//[sdk](../../../index.md)/[com.robotemi.sdk.activitystream](../index.md)/[ActivityStreamListItem](index.md)/[isFileProvided](is-file-provided.md)

# isFileProvided

[androidJvm]\
open val [isFileProvided](is-file-provided.md): [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)
