//[sdk](../../../index.md)/[com.robotemi.sdk.activitystream](../index.md)/[ActivityStreamListItem](index.md)/[date](date.md)

# date

[androidJvm]\

@Expose

@SerializedName(value = &quot;date&quot;)

@get:Nullable

open val [date](date.md): [String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html)
