//[sdk](../../../../../index.md)/[com.robotemi.sdk.activitystream](../../../index.md)/[ActivityStreamObject](../../index.md)/[ActivityType](../index.md)/[PHOTO](index.md)

# PHOTO

[androidJvm]\
[PHOTO](index.md)
