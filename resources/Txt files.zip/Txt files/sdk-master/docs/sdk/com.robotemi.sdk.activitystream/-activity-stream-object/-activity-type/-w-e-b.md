[sdk](../../../index.md) / [com.robotemi.sdk.activitystream](../../index.md) / [ActivityStreamObject](../index.md) / [ActivityType](index.md) / [WEB](./-w-e-b.md)

# WEB

`WEB`

### Inherited Functions

| Name | Summary |
|---|---|
| [getTypeName](get-type-name.md) | `fun getTypeName(): `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`!` |
