//[sdk](../../../index.md)/[com.robotemi.sdk.activitystream](../index.md)/[ActivityStreamObject](index.md)/[mediaObject](media-object.md)

# mediaObject

[androidJvm]\

@Expose

@SerializedName(value = &quot;media&quot;)

open val [mediaObject](media-object.md): [MediaObject](../../com.robotemi.sdk/-media-object/index.md)
