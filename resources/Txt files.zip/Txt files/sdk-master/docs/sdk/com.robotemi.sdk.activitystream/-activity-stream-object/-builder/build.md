//[sdk](../../../../index.md)/[com.robotemi.sdk.activitystream](../../index.md)/[ActivityStreamObject](../index.md)/[Builder](index.md)/[build](build.md)

# build

[androidJvm]\
open fun [build](build.md)(): [ActivityStreamObject](../index.md)
