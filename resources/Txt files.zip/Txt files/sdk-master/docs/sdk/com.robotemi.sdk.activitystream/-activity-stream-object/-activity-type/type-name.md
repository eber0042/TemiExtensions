//[sdk](../../../../index.md)/[com.robotemi.sdk.activitystream](../../index.md)/[ActivityStreamObject](../index.md)/[ActivityType](index.md)/[typeName](type-name.md)

# typeName

[androidJvm]\
open val [typeName](type-name.md): [String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html)
