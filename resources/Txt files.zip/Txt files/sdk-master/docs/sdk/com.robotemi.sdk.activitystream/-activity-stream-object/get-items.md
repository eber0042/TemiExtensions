[sdk](../../index.md) / [com.robotemi.sdk.activitystream](../index.md) / [ActivityStreamObject](index.md) / [getItems](./get-items.md)

# getItems

`open fun getItems(): `[`MutableList`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-mutable-list/index.html)`<`[`ActivityStreamListItem`](../-activity-stream-list-item/index.md)`!>!`