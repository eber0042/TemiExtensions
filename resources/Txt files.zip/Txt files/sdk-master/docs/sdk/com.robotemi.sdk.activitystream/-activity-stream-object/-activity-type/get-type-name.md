[sdk](../../../index.md) / [com.robotemi.sdk.activitystream](../../index.md) / [ActivityStreamObject](../index.md) / [ActivityType](index.md) / [getTypeName](./get-type-name.md)

# getTypeName

`fun getTypeName(): `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`!`