//[sdk](../../../../index.md)/[com.robotemi.sdk.activitystream](../../index.md)/[ActivityStreamObject](../index.md)/[Builder](index.md)/[title](title.md)

# title

[androidJvm]\
open fun [title](title.md)(@NonNulltitle: [String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html)): [ActivityStreamObject.Builder](index.md)
