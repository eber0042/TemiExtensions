//[sdk](../../../../index.md)/[com.robotemi.sdk.activitystream](../../index.md)/[ActivityStreamObject](../index.md)/[Builder](index.md)/[activityType](activity-type.md)

# activityType

[androidJvm]\
open fun [activityType](activity-type.md)(@NonNullactivityType: [Any](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-any/index.html)): [ActivityStreamObject.Builder](index.md)
