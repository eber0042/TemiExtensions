//[sdk](../../../index.md)/[com.robotemi.sdk.activitystream](../index.md)/[ActivityStreamObject](index.md)/[builder](builder.md)

# builder

[androidJvm]\
open fun [builder](builder.md)(): [ActivityStreamObject.Builder](-builder/index.md)
