//[sdk](../../../../../index.md)/[com.robotemi.sdk.activitystream](../../../index.md)/[ActivityStreamObject](../../index.md)/[ActivityType](../index.md)/[WEB](index.md)

# WEB

[androidJvm]\
[WEB](index.md)
