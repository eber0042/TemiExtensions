//[sdk](../../../index.md)/[com.robotemi.sdk.activitystream](../index.md)/[ActivityStreamObject](index.md)/[numOfProvidedFiles](num-of-provided-files.md)

# numOfProvidedFiles

[androidJvm]\
open val [numOfProvidedFiles](num-of-provided-files.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)
