[sdk](../../../index.md) / [com.robotemi.sdk.activitystream](../../index.md) / [ActivityStreamObject](../index.md) / [Builder](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`Builder()`