//[sdk](../../../index.md)/[com.robotemi.sdk.activitystream](../index.md)/[ActivityStreamUtils](index.md)/[doAfterActivityPublished](do-after-activity-published.md)

# doAfterActivityPublished

[androidJvm]\
open fun [doAfterActivityPublished](do-after-activity-published.md)(activityStreamObject: [ActivityStreamObject](../-activity-stream-object/index.md))
