//[sdk](../../../index.md)/[com.robotemi.sdk.activitystream](../index.md)/[ActivityStreamUtils](index.md)

# ActivityStreamUtils

[androidJvm]\
class [ActivityStreamUtils](index.md)

## Functions

| Name | Summary |
|---|---|
| [doAfterActivityPublished](do-after-activity-published.md) | [androidJvm]<br>open fun [doAfterActivityPublished](do-after-activity-published.md)(activityStreamObject: [ActivityStreamObject](../-activity-stream-object/index.md)) |
| [handleActivityStreamObject](handle-activity-stream-object.md) | [androidJvm]<br>open fun [handleActivityStreamObject](handle-activity-stream-object.md)(@NonNullactivityStreamObject: [ActivityStreamObject](../-activity-stream-object/index.md)) |
