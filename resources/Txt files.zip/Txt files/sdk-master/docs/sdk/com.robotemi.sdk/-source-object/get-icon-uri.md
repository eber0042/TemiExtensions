[sdk](../../index.md) / [com.robotemi.sdk](../index.md) / [SourceObject](index.md) / [getIconUri](./get-icon-uri.md)

# getIconUri

`open fun getIconUri(): `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`!`