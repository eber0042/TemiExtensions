//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[SourceObject](index.md)/[name](name.md)

# name

[androidJvm]\

@Expose

@SerializedName(value = &quot;name&quot;)

open val [name](name.md): [String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html)
