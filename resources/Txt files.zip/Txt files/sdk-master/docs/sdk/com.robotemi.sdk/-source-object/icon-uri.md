//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[SourceObject](index.md)/[iconUri](icon-uri.md)

# iconUri

[androidJvm]\

@Expose

@SerializedName(value = &quot;iconUri&quot;)

open val [iconUri](icon-uri.md): [String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html)
