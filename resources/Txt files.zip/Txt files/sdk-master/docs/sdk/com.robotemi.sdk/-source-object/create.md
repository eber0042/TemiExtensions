//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[SourceObject](index.md)/[create](create.md)

# create

[androidJvm]\
open fun [create](create.md)(name: [String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html), iconUri: [String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html)): [SourceObject](index.md)
