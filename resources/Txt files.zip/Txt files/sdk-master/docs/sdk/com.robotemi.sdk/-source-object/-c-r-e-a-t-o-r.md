//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[SourceObject](index.md)/[CREATOR](-c-r-e-a-t-o-r.md)

# CREATOR

[androidJvm]\
val [CREATOR](-c-r-e-a-t-o-r.md): Parcelable.Creator&lt;[SourceObject](index.md)&gt;
