//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[MediaContainer](index.md)/[getMimeType](get-mime-type.md)

# getMimeType

[androidJvm]\
abstract fun [getMimeType](get-mime-type.md)(): [MediaObject.MimeType](../-media-object/-mime-type/index.md)
