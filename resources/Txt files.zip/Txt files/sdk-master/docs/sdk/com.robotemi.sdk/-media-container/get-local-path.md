//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[MediaContainer](index.md)/[getLocalPath](get-local-path.md)

# getLocalPath

[androidJvm]\
abstract fun [getLocalPath](get-local-path.md)(): [String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html)
