//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[MediaContainer](index.md)/[getMediaUri](get-media-uri.md)

# getMediaUri

[androidJvm]\
abstract fun [getMediaUri](get-media-uri.md)(): [String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html)
