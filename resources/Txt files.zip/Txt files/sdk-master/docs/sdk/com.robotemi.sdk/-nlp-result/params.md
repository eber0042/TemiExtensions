//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[NlpResult](index.md)/[params](params.md)

# params

[androidJvm]\
open var [params](params.md): [Map](https://docs.oracle.com/javase/8/docs/api/java/util/Map.html)&lt;[String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html), [String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html)&gt;
