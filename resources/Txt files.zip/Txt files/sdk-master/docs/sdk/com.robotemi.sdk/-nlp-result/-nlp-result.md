//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[NlpResult](index.md)/[NlpResult](-nlp-result.md)

# NlpResult

[androidJvm]\
open fun [NlpResult](-nlp-result.md)()
