//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[NlpResult](index.md)/[action](action.md)

# action

[androidJvm]\
open var [action](action.md): [String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html)
