//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[NlpResult](index.md)/[resolvedQuery](resolved-query.md)

# resolvedQuery

[androidJvm]\
open var [resolvedQuery](resolved-query.md): [String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html)
