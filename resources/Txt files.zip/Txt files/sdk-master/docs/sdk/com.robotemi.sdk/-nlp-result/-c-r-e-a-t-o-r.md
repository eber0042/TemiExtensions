//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[NlpResult](index.md)/[CREATOR](-c-r-e-a-t-o-r.md)

# CREATOR

[androidJvm]\
val [CREATOR](-c-r-e-a-t-o-r.md): Parcelable.Creator&lt;[NlpResult](index.md)&gt;
