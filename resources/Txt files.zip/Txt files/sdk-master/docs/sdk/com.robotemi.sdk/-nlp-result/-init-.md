[sdk](../../index.md) / [com.robotemi.sdk](../index.md) / [NlpResult](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`protected NlpResult(in: `[`Parcel`](https://developer.android.com/reference/android/os/Parcel.html)`!)`
`NlpResult()`