//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[BatteryData](index.md)/[level](level.md)

# level

[androidJvm]\

@get:[JvmName](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.jvm/-jvm-name/index.html)(name = &quot;getBatteryPercentage&quot;)

val [level](level.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)
