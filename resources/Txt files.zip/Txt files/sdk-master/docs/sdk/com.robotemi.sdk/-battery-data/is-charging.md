//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[BatteryData](index.md)/[isCharging](is-charging.md)

# isCharging

[androidJvm]\
val [isCharging](is-charging.md): [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)
