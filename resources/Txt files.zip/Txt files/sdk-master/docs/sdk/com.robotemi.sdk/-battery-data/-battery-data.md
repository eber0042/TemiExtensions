//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[BatteryData](index.md)/[BatteryData](-battery-data.md)

# BatteryData

[androidJvm]\
fun [BatteryData](-battery-data.md)(source: Parcel)

fun [BatteryData](-battery-data.md)(level: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html), isCharging: [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html))
