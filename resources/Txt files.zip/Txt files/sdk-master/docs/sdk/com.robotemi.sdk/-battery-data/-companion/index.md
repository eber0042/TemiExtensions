//[sdk](../../../../index.md)/[com.robotemi.sdk](../../index.md)/[BatteryData](../index.md)/[Companion](index.md)

# Companion

[androidJvm]\
object [Companion](index.md)

## Properties

| Name | Summary |
|---|---|
| [CREATOR](-c-r-e-a-t-o-r.md) | [androidJvm]<br>@[JvmField](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.jvm/-jvm-field/index.html)<br>val [CREATOR](-c-r-e-a-t-o-r.md): Parcelable.Creator&lt;[BatteryData](../index.md)&gt; |
