[sdk](../../index.md) / [com.robotemi.sdk](../index.md) / [BatteryData](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`BatteryData(source: `[`Parcel`](https://developer.android.com/reference/android/os/Parcel.html)`)`
`BatteryData(level: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`, isCharging: `[`Boolean`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)`)`