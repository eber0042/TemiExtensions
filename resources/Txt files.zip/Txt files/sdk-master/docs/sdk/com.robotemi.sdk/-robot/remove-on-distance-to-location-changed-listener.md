//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnDistanceToLocationChangedListener](remove-on-distance-to-location-changed-listener.md)

# removeOnDistanceToLocationChangedListener

[androidJvm]\

@UiThread

fun [removeOnDistanceToLocationChangedListener](remove-on-distance-to-location-changed-listener.md)(listener: [OnDistanceToLocationChangedListener](../../com.robotemi.sdk.navigation.listener/-on-distance-to-location-changed-listener/index.md))
