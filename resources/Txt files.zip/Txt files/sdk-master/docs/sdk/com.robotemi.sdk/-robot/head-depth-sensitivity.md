//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[headDepthSensitivity](head-depth-sensitivity.md)

# headDepthSensitivity

[androidJvm]\

@get:CheckResult

var [headDepthSensitivity](head-depth-sensitivity.md): [SensitivityLevel](../../com.robotemi.sdk.constants/-sensitivity-level/index.md)

Get or set the sensitivity of head depth.
