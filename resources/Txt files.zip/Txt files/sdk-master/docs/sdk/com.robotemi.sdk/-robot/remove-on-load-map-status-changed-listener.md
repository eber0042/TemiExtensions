//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnLoadMapStatusChangedListener](remove-on-load-map-status-changed-listener.md)

# removeOnLoadMapStatusChangedListener

[androidJvm]\

@UiThread

fun [removeOnLoadMapStatusChangedListener](remove-on-load-map-status-changed-listener.md)(listener: [OnLoadMapStatusChangedListener](../../com.robotemi.sdk.map/-on-load-map-status-changed-listener/index.md))
