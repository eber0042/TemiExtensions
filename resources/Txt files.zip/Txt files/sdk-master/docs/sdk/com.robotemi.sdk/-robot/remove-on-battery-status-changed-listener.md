//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnBatteryStatusChangedListener](remove-on-battery-status-changed-listener.md)

# removeOnBatteryStatusChangedListener

[androidJvm]\

@UiThread

fun [removeOnBatteryStatusChangedListener](remove-on-battery-status-changed-listener.md)(listener: [OnBatteryStatusChangedListener](../../com.robotemi.sdk.listeners/-on-battery-status-changed-listener/index.md))
