//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[isReady](is-ready.md)

# isReady

[androidJvm]\

@get:CheckResult

val [isReady](is-ready.md): [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)
