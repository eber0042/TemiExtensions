//[sdk](../../../../index.md)/[com.robotemi.sdk](../../index.md)/[Robot](../index.md)/[ConversationViewAttachesListener](index.md)

# ConversationViewAttachesListener

[androidJvm]\
interface [ConversationViewAttachesListener](index.md)

## Functions

| Name | Summary |
|---|---|
| [onConversationAttaches](on-conversation-attaches.md) | [androidJvm]<br>abstract fun [onConversationAttaches](on-conversation-attaches.md)(isAttached: [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)) |
