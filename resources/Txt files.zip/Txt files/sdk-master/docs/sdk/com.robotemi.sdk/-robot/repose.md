//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[repose](repose.md)

# repose

[androidJvm]\
fun [repose](repose.md)()

Start positing to locate the position of temi.
