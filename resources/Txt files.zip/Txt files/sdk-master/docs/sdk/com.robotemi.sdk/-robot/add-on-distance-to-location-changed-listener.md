//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addOnDistanceToLocationChangedListener](add-on-distance-to-location-changed-listener.md)

# addOnDistanceToLocationChangedListener

[androidJvm]\

@UiThread

fun [addOnDistanceToLocationChangedListener](add-on-distance-to-location-changed-listener.md)(listener: [OnDistanceToLocationChangedListener](../../com.robotemi.sdk.navigation.listener/-on-distance-to-location-changed-listener/index.md))
