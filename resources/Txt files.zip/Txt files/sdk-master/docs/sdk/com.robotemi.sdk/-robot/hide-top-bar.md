//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[hideTopBar](hide-top-bar.md)

# hideTopBar

[androidJvm]\
fun [hideTopBar](hide-top-bar.md)()

Hide the top bar of Launcher.
