//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[locations](locations.md)

# locations

[androidJvm]\

@get:CheckResult

val [locations](locations.md): [List](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)&lt;[String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)&gt;

Retrieve list of previously saved locations.

#### Return

List of saved locations.
