//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnContinuousFaceRecognizedListener](remove-on-continuous-face-recognized-listener.md)

# removeOnContinuousFaceRecognizedListener

[androidJvm]\

@UiThread

fun [removeOnContinuousFaceRecognizedListener](remove-on-continuous-face-recognized-listener.md)(listener: [OnContinuousFaceRecognizedListener](../../com.robotemi.sdk.face/-on-continuous-face-recognized-listener/index.md))
