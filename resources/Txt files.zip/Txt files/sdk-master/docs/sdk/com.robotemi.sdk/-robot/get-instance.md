[sdk](../../index.md) / [com.robotemi.sdk](../index.md) / [Robot](index.md) / [getInstance](./get-instance.md)

# getInstance

`@JvmStatic fun getInstance(): `[`Robot`](index.md)