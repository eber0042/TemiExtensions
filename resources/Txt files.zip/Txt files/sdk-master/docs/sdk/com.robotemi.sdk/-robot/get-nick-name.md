//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[getNickName](get-nick-name.md)

# getNickName

[androidJvm]\

@CheckResult

fun [getNickName](get-nick-name.md)(): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

Get temi's nick name

#### Return
