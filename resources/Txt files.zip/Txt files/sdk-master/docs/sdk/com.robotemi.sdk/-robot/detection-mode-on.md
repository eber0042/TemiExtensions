//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[detectionModeOn](detection-mode-on.md)

# detectionModeOn

[androidJvm]\

@get:[JvmName](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.jvm/-jvm-name/index.html)(name = &quot;isDetectionModeOn&quot;)

@get:CheckResult

var [detectionModeOn](detection-mode-on.md): [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)

Turn on/off detection mode.
