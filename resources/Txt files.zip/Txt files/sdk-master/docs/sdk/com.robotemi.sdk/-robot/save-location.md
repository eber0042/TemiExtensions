//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[saveLocation](save-location.md)

# saveLocation

[androidJvm]\
fun [saveLocation](save-location.md)(name: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)): [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)

Save location.

#### Return

Result of a successful or failed operation.

## Parameters

androidJvm

| | |
|---|---|
| name | Location name. |
