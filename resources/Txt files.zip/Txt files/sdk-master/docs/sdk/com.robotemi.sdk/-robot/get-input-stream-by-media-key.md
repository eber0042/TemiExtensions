//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[getInputStreamByMediaKey](get-input-stream-by-media-key.md)

# getInputStreamByMediaKey

[androidJvm]\

@Nullable

@WorkerThread

fun [getInputStreamByMediaKey](get-input-stream-by-media-key.md)(contentType: [ContentType](../../com.robotemi.sdk.constants/-content-type/index.md), mediaKey: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)): [InputStream](https://docs.oracle.com/javase/8/docs/api/java/io/InputStream.html)?
