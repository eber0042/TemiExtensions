//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addOnRobotLiftedListener](add-on-robot-lifted-listener.md)

# addOnRobotLiftedListener

[androidJvm]\

@UiThread

fun [addOnRobotLiftedListener](add-on-robot-lifted-listener.md)(listener: [OnRobotLiftedListener](../../com.robotemi.sdk.listeners/-on-robot-lifted-listener/index.md))
