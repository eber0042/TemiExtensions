//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[stopFaceRecognition](stop-face-recognition.md)

# stopFaceRecognition

[androidJvm]\
fun [stopFaceRecognition](stop-face-recognition.md)()

Stop face recognition.
