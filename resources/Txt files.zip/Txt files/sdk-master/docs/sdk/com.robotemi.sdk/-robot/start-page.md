//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[startPage](start-page.md)

# startPage

[androidJvm]\
fun [startPage](start-page.md)(page: [Page](../../com.robotemi.sdk.constants/-page/index.md))

Start Launcher's internal page.

## Parameters

androidJvm

| | |
|---|---|
| page | Target page. |
