//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addOnMovementVelocityChangedListener](add-on-movement-velocity-changed-listener.md)

# addOnMovementVelocityChangedListener

[androidJvm]\

@UiThread

fun [addOnMovementVelocityChangedListener](add-on-movement-velocity-changed-listener.md)(listener: [OnMovementVelocityChangedListener](../../com.robotemi.sdk.listeners/-on-movement-velocity-changed-listener/index.md))
