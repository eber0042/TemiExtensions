//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[shutdown](shutdown.md)

# shutdown

[androidJvm]\
fun [shutdown](shutdown.md)()

Shut down temi.
