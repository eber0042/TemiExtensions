//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[setSoundMode](set-sound-mode.md)

# setSoundMode

[androidJvm]\
fun [setSoundMode](set-sound-mode.md)(soundMode: [SoundMode](../../com.robotemi.sdk.constants/-sound-mode/index.md))

Sound mode

## Parameters

androidJvm

| | |
|---|---|
| soundMode |  |
