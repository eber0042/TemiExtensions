//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[constraintBeWith](constraint-be-with.md)

# constraintBeWith

[androidJvm]\
fun [constraintBeWith](constraint-be-with.md)()

Start constraint follow. Add [OnConstraintBeWithStatusChangedListener](../../com.robotemi.sdk.listeners/-on-constraint-be-with-status-changed-listener/index.md) to listen for status changed.
