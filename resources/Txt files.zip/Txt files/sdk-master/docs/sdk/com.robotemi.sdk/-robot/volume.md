//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[volume](volume.md)

# volume

[androidJvm]\

@get:CheckResult

var [volume](volume.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)

Volume of Launcher OS.
