//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[setKioskModeOn](set-kiosk-mode-on.md)

# setKioskModeOn

[androidJvm]\
fun [setKioskModeOn](set-kiosk-mode-on.md)(on: [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html) = true)
