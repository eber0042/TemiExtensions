//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[getAllSequences](get-all-sequences.md)

# getAllSequences

[androidJvm]\

@WorkerThread

@CheckResult

@[JvmOverloads](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.jvm/-jvm-overloads/index.html)

fun [getAllSequences](get-all-sequences.md)(tags: [List](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)&lt;[String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)&gt; = emptyList()): [List](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)&lt;[SequenceModel](../../com.robotemi.sdk.sequence/-sequence-model/index.md)&gt;

Fetch all sequences user created on the Web platform.

#### Return

List holds all sequences.
