//[sdk](../../../../index.md)/[com.robotemi.sdk](../../index.md)/[Robot](../index.md)/[NlpListener](index.md)

# NlpListener

[androidJvm]\
interface [NlpListener](index.md)

## Functions

| Name | Summary |
|---|---|
| [onNlpCompleted](on-nlp-completed.md) | [androidJvm]<br>abstract fun [onNlpCompleted](on-nlp-completed.md)(nlpResult: [NlpResult](../../-nlp-result/index.md)) |
