//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[wakeup](wakeup.md)

# wakeup

[androidJvm]\
fun [wakeup](wakeup.md)()

Trigger temi's wakeup programmatically.
