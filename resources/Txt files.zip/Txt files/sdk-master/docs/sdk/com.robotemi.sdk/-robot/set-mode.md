//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[setMode](set-mode.md)

# setMode

[androidJvm]\
fun [setMode](set-mode.md)(mode: [Mode](../../com.robotemi.sdk.constants/-mode/index.md))

Set system mode.

## Parameters

androidJvm

| | |
|---|---|
| mode | Default, Greet, Privacy |
