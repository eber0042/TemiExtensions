//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[startDefaultNlu](start-default-nlu.md)

# startDefaultNlu

[androidJvm]\
fun [startDefaultNlu](start-default-nlu.md)(text: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html))

Trigger temi Launcher's default NLU service.

## Parameters

androidJvm

| | |
|---|---|
| text | The text to be processed. |
