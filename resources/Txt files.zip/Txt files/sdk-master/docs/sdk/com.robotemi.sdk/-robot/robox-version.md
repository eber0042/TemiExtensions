//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[roboxVersion](robox-version.md)

# roboxVersion

[androidJvm]\

@get:CheckResult

val [roboxVersion](robox-version.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

Get version of the Robox.
