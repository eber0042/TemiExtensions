//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[navigationSafety](navigation-safety.md)

# navigationSafety

[androidJvm]\

@get:CheckResult

var [navigationSafety](navigation-safety.md): [SafetyLevel](../../com.robotemi.sdk.navigation.model/-safety-level/index.md)

Set navigation safety level.
