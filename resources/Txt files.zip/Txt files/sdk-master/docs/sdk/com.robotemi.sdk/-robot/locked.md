//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[locked](locked.md)

# locked

[androidJvm]\

@get:[JvmName](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.jvm/-jvm-name/index.html)(name = &quot;isLocked&quot;)

@get:CheckResult

var [locked](locked.md): [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)

Check if temi is locked.
