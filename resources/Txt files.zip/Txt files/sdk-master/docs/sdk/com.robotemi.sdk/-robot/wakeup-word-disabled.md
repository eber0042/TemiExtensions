//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[wakeupWordDisabled](wakeup-word-disabled.md)

# wakeupWordDisabled

[androidJvm]\

@get:CheckResult

@get:[JvmName](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.jvm/-jvm-name/index.html)(name = &quot;isWakeupDisabled&quot;)

val [wakeupWordDisabled](wakeup-word-disabled.md): [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)
