//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[pauseMediaBar](pause-media-bar.md)

# pauseMediaBar

[androidJvm]\
~~fun~~ [~~pauseMediaBar~~](pause-media-bar.md)~~(~~~~)~~
