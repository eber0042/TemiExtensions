//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[setHardButtonMode](set-hard-button-mode.md)

# setHardButtonMode

[androidJvm]\
fun [setHardButtonMode](set-hard-button-mode.md)(type: [HardButton](../../com.robotemi.sdk.constants/-hard-button/index.md), mode: [HardButton.Mode](../../com.robotemi.sdk.constants/-hard-button/-mode/index.md))
