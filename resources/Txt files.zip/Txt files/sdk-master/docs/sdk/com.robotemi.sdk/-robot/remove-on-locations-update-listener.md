//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnLocationsUpdateListener](remove-on-locations-update-listener.md)

# removeOnLocationsUpdateListener

[androidJvm]\

@UiThread

fun [removeOnLocationsUpdateListener](remove-on-locations-update-listener.md)(listener: [OnLocationsUpdatedListener](../../com.robotemi.sdk.listeners/-on-locations-updated-listener/index.md))
