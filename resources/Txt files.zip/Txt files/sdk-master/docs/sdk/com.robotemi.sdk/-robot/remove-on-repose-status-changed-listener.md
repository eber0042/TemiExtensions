//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnReposeStatusChangedListener](remove-on-repose-status-changed-listener.md)

# removeOnReposeStatusChangedListener

[androidJvm]\

@UiThread

fun [removeOnReposeStatusChangedListener](remove-on-repose-status-changed-listener.md)(listener: [OnReposeStatusChangedListener](../../com.robotemi.sdk.navigation.listener/-on-repose-status-changed-listener/index.md))
