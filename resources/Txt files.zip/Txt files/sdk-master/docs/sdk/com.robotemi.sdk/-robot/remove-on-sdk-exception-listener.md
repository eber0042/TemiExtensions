//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnSdkExceptionListener](remove-on-sdk-exception-listener.md)

# removeOnSdkExceptionListener

[androidJvm]\

@UiThread

fun [removeOnSdkExceptionListener](remove-on-sdk-exception-listener.md)(listener: [OnSdkExceptionListener](../../com.robotemi.sdk.exception/-on-sdk-exception-listener/index.md))
