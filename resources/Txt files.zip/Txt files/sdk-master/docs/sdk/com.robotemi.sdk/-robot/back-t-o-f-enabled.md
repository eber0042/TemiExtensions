//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[backTOFEnabled](back-t-o-f-enabled.md)

# backTOFEnabled

[androidJvm]\

@get:[JvmName](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.jvm/-jvm-name/index.html)(name = &quot;isBackTOFEnabled&quot;)

@get:CheckResult

var [backTOFEnabled](back-t-o-f-enabled.md): [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)

Check or set if the back TOF is enabled.
