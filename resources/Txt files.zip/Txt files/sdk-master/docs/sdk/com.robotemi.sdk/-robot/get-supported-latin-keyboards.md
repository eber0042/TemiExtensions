//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[getSupportedLatinKeyboards](get-supported-latin-keyboards.md)

# getSupportedLatinKeyboards

[androidJvm]\

@CheckResult

fun [getSupportedLatinKeyboards](get-supported-latin-keyboards.md)(): [Map](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-map/index.html)&lt;[String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html), [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)&gt;

Get the supported latin keyboards

#### Return
