//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[cancelAllTtsRequests](cancel-all-tts-requests.md)

# cancelAllTtsRequests

[androidJvm]\
fun [cancelAllTtsRequests](cancel-all-tts-requests.md)()

Stops currently processed TTS request and empty the queue.
