//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addOnDetectionStateChangedListener](add-on-detection-state-changed-listener.md)

# addOnDetectionStateChangedListener

[androidJvm]\

@UiThread

fun [addOnDetectionStateChangedListener](add-on-detection-state-changed-listener.md)(listener: [OnDetectionStateChangedListener](../../com.robotemi.sdk.listeners/-on-detection-state-changed-listener/index.md))
