//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addOnSequencePlayStatusChangedListener](add-on-sequence-play-status-changed-listener.md)

# addOnSequencePlayStatusChangedListener

[androidJvm]\

@UiThread

fun [addOnSequencePlayStatusChangedListener](add-on-sequence-play-status-changed-listener.md)(listener: [OnSequencePlayStatusChangedListener](../../com.robotemi.sdk.sequence/-on-sequence-play-status-changed-listener/index.md))
