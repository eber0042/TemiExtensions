//[sdk](../../../../index.md)/[com.robotemi.sdk](../../index.md)/[Robot](../index.md)/[TtsListener](index.md)

# TtsListener

[androidJvm]\
interface [TtsListener](index.md)

## Functions

| Name | Summary |
|---|---|
| [onTtsStatusChanged](on-tts-status-changed.md) | [androidJvm]<br>abstract fun [onTtsStatusChanged](on-tts-status-changed.md)(ttsRequest: [TtsRequest](../../-tts-request/index.md)) |
