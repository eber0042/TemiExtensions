//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeAlertNotification](remove-alert-notification.md)

# removeAlertNotification

[androidJvm]\
fun [removeAlertNotification](remove-alert-notification.md)(notification: [AlertNotification](../../com.robotemi.sdk.notification/-alert-notification/index.md))
