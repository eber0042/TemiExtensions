//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[showTopBar](show-top-bar.md)

# showTopBar

[androidJvm]\
fun [showTopBar](show-top-bar.md)()

Show the top bar of Launcher.
