//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[goToSpeed](go-to-speed.md)

# goToSpeed

[androidJvm]\

@get:CheckResult

var [goToSpeed](go-to-speed.md): [SpeedLevel](../../com.robotemi.sdk.navigation.model/-speed-level/index.md)

Set navigation speed level.
