//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addAsrListener](add-asr-listener.md)

# addAsrListener

[androidJvm]\

@UiThread

fun [addAsrListener](add-asr-listener.md)(asrListener: [Robot.AsrListener](-asr-listener/index.md))
