//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnMovementVelocityChangedListener](remove-on-movement-velocity-changed-listener.md)

# removeOnMovementVelocityChangedListener

[androidJvm]\

@UiThread

fun [removeOnMovementVelocityChangedListener](remove-on-movement-velocity-changed-listener.md)(listener: [OnMovementVelocityChangedListener](../../com.robotemi.sdk.listeners/-on-movement-velocity-changed-listener/index.md))
