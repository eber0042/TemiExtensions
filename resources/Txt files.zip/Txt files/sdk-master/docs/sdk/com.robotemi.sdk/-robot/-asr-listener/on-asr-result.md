//[sdk](../../../../index.md)/[com.robotemi.sdk](../../index.md)/[Robot](../index.md)/[AsrListener](index.md)/[onAsrResult](on-asr-result.md)

# onAsrResult

[androidJvm]\
abstract fun [onAsrResult](on-asr-result.md)(asrResult: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html))
