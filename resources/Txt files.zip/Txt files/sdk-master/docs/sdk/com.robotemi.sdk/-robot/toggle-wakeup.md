//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[toggleWakeup](toggle-wakeup.md)

# toggleWakeup

[androidJvm]\
fun [toggleWakeup](toggle-wakeup.md)(disabled: [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html))

Toggle the wakeup trigger on and off.

## Parameters

androidJvm

| | |
|---|---|
| disabled | Set true to disable the wakeup or false to enable it. |
