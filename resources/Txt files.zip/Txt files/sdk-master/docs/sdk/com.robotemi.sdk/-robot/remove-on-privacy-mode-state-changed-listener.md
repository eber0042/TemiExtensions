//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnPrivacyModeStateChangedListener](remove-on-privacy-mode-state-changed-listener.md)

# removeOnPrivacyModeStateChangedListener

[androidJvm]\

@UiThread

fun [removeOnPrivacyModeStateChangedListener](remove-on-privacy-mode-state-changed-listener.md)(listener: [OnPrivacyModeChangedListener](../../com.robotemi.sdk.listeners/-on-privacy-mode-changed-listener/index.md))
