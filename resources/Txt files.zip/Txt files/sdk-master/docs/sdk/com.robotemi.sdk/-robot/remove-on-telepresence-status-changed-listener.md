//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnTelepresenceStatusChangedListener](remove-on-telepresence-status-changed-listener.md)

# removeOnTelepresenceStatusChangedListener

[androidJvm]\

@UiThread

fun [removeOnTelepresenceStatusChangedListener](remove-on-telepresence-status-changed-listener.md)(listener: [OnTelepresenceStatusChangedListener](../../com.robotemi.sdk.listeners/-on-telepresence-status-changed-listener/index.md))

Stop listening for Telepresence Status changes.

## Parameters

androidJvm

| | |
|---|---|
| listener | The listener you added before. |
