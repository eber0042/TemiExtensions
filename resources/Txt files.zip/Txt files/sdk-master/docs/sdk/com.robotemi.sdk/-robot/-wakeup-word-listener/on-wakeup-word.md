//[sdk](../../../../index.md)/[com.robotemi.sdk](../../index.md)/[Robot](../index.md)/[WakeupWordListener](index.md)/[onWakeupWord](on-wakeup-word.md)

# onWakeupWord

[androidJvm]\
abstract fun [onWakeupWord](on-wakeup-word.md)(wakeupWord: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html), direction: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html))
