//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[onStart](on-start.md)

# onStart

[androidJvm]\

@UiThread

fun [onStart](on-start.md)(activityInfo: ActivityInfo)
