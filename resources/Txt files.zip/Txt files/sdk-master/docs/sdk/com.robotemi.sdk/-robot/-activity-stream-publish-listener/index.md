//[sdk](../../../../index.md)/[com.robotemi.sdk](../../index.md)/[Robot](../index.md)/[ActivityStreamPublishListener](index.md)

# ActivityStreamPublishListener

[androidJvm]\
interface [ActivityStreamPublishListener](index.md)

## Functions

| Name | Summary |
|---|---|
| [onPublish](on-publish.md) | [androidJvm]<br>abstract fun [onPublish](on-publish.md)(message: [ActivityStreamPublishMessage](../../../com.robotemi.sdk.activitystream/-activity-stream-publish-message/index.md)) |
