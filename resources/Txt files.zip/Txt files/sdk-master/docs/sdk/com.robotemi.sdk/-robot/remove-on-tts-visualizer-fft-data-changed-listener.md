//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnTtsVisualizerFftDataChangedListener](remove-on-tts-visualizer-fft-data-changed-listener.md)

# removeOnTtsVisualizerFftDataChangedListener

[androidJvm]\

@UiThread

fun [removeOnTtsVisualizerFftDataChangedListener](remove-on-tts-visualizer-fft-data-changed-listener.md)(onTtsVisualizerFftDataChangedListener: [OnTtsVisualizerFftDataChangedListener](../../com.robotemi.sdk.listeners/-on-tts-visualizer-fft-data-changed-listener/index.md))
