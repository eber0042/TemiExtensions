//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addOnRobotReadyListener](add-on-robot-ready-listener.md)

# addOnRobotReadyListener

[androidJvm]\

@UiThread

fun [addOnRobotReadyListener](add-on-robot-ready-listener.md)(onRobotReadyListener: [OnRobotReadyListener](../../com.robotemi.sdk.listeners/-on-robot-ready-listener/index.md))
