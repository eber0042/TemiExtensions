//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addConversationViewAttachesListener](add-conversation-view-attaches-listener.md)

# addConversationViewAttachesListener

[androidJvm]\

@UiThread

fun [addConversationViewAttachesListener](add-conversation-view-attaches-listener.md)(conversationViewAttachesListener: [Robot.ConversationViewAttachesListener](-conversation-view-attaches-listener/index.md))
