//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addNlpListener](add-nlp-listener.md)

# addNlpListener

[androidJvm]\

@UiThread

fun [addNlpListener](add-nlp-listener.md)(nlpListener: [Robot.NlpListener](-nlp-listener/index.md))
