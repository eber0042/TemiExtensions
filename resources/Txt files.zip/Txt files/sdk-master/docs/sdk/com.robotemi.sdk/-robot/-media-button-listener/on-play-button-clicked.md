//[sdk](../../../../index.md)/[com.robotemi.sdk](../../index.md)/[Robot](../index.md)/[MediaButtonListener](index.md)/[onPlayButtonClicked](on-play-button-clicked.md)

# onPlayButtonClicked

[androidJvm]\
abstract fun [onPlayButtonClicked](on-play-button-clicked.md)(play: [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html))
