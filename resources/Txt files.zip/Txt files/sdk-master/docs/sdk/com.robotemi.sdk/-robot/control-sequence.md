//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[controlSequence](control-sequence.md)

# controlSequence

[androidJvm]\
fun [controlSequence](control-sequence.md)(sequenceCommand: [SequenceCommand](../../com.robotemi.sdk.constants/-sequence-command/index.md))

Control current playing sequence.

## Parameters

androidJvm

| | |
|---|---|
| sequenceCommand | Operations for controlling sequence, see [SequenceCommand](../../com.robotemi.sdk.constants/-sequence-command/index.md). |
