//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addOnDisabledFeatureListUpdatedListener](add-on-disabled-feature-list-updated-listener.md)

# addOnDisabledFeatureListUpdatedListener

[androidJvm]\

@UiThread

fun [addOnDisabledFeatureListUpdatedListener](add-on-disabled-feature-list-updated-listener.md)(listener: [OnDisabledFeatureListUpdatedListener](../../com.robotemi.sdk.listeners/-on-disabled-feature-list-updated-listener/index.md))
