//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnBeWithMeStatusChangedListener](remove-on-be-with-me-status-changed-listener.md)

# removeOnBeWithMeStatusChangedListener

[androidJvm]\

@UiThread

fun [removeOnBeWithMeStatusChangedListener](remove-on-be-with-me-status-changed-listener.md)(listener: [OnBeWithMeStatusChangedListener](../../com.robotemi.sdk.listeners/-on-be-with-me-status-changed-listener/index.md))
