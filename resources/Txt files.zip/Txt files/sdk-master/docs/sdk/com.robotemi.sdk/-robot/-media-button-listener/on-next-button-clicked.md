//[sdk](../../../../index.md)/[com.robotemi.sdk](../../index.md)/[Robot](../index.md)/[MediaButtonListener](index.md)/[onNextButtonClicked](on-next-button-clicked.md)

# onNextButtonClicked

[androidJvm]\
abstract fun [onNextButtonClicked](on-next-button-clicked.md)()
