//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addOnDetectionDataChangedListener](add-on-detection-data-changed-listener.md)

# addOnDetectionDataChangedListener

[androidJvm]\

@UiThread

fun [addOnDetectionDataChangedListener](add-on-detection-data-changed-listener.md)(listener: [OnDetectionDataChangedListener](../../com.robotemi.sdk.listeners/-on-detection-data-changed-listener/index.md))
