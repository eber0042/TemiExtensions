//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnRobotReadyListener](remove-on-robot-ready-listener.md)

# removeOnRobotReadyListener

[androidJvm]\

@UiThread

fun [removeOnRobotReadyListener](remove-on-robot-ready-listener.md)(onRobotReadyListener: [OnRobotReadyListener](../../com.robotemi.sdk.listeners/-on-robot-ready-listener/index.md))
