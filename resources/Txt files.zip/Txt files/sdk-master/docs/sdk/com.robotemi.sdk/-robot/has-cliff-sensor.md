//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[hasCliffSensor](has-cliff-sensor.md)

# hasCliffSensor

[androidJvm]\

@CheckResult

fun [hasCliffSensor](has-cliff-sensor.md)(): [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)

Check if the robot has the cliff sensor.
