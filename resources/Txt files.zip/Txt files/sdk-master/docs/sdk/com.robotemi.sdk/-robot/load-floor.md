//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[loadFloor](load-floor.md)

# loadFloor

[androidJvm]\
fun [loadFloor](load-floor.md)(floorId: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html), position: [Position](../../com.robotemi.sdk.navigation.model/-position/index.md))
