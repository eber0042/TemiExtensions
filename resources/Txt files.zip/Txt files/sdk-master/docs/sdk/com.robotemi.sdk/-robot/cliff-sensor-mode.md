//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[cliffSensorMode](cliff-sensor-mode.md)

# cliffSensorMode

[androidJvm]\

@get:CheckResult

var [cliffSensorMode](cliff-sensor-mode.md): [CliffSensorMode](../../com.robotemi.sdk.constants/-cliff-sensor-mode/index.md)

Check and set the mode of cliff sensor, see [CliffSensorMode](../../com.robotemi.sdk.constants/-cliff-sensor-mode/index.md)
