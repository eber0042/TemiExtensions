//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addOnReposeStatusChangedListener](add-on-repose-status-changed-listener.md)

# addOnReposeStatusChangedListener

[androidJvm]\

@UiThread

fun [addOnReposeStatusChangedListener](add-on-repose-status-changed-listener.md)(listener: [OnReposeStatusChangedListener](../../com.robotemi.sdk.navigation.listener/-on-repose-status-changed-listener/index.md))
