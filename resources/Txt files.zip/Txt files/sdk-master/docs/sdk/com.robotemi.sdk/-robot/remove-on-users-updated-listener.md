//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnUsersUpdatedListener](remove-on-users-updated-listener.md)

# removeOnUsersUpdatedListener

[androidJvm]\

@UiThread

fun [removeOnUsersUpdatedListener](remove-on-users-updated-listener.md)(listener: [OnUsersUpdatedListener](../../com.robotemi.sdk.listeners/-on-users-updated-listener/index.md))

Stop listening for user information updates.

## Parameters

androidJvm

| | |
|---|---|
| listener | The listener you added before. |
