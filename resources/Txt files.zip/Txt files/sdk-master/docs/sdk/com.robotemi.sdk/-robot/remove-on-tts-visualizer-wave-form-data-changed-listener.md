//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnTtsVisualizerWaveFormDataChangedListener](remove-on-tts-visualizer-wave-form-data-changed-listener.md)

# removeOnTtsVisualizerWaveFormDataChangedListener

[androidJvm]\

@UiThread

fun [removeOnTtsVisualizerWaveFormDataChangedListener](remove-on-tts-visualizer-wave-form-data-changed-listener.md)(onTtsVisualizerWaveFormDataChangedListener: [OnTtsVisualizerWaveFormDataChangedListener](../../com.robotemi.sdk.listeners/-on-tts-visualizer-wave-form-data-changed-listener/index.md))
