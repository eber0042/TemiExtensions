//[sdk](../../../../index.md)/[com.robotemi.sdk](../../index.md)/[Robot](../index.md)/[NotificationListener](index.md)

# NotificationListener

[androidJvm]\
interface [NotificationListener](index.md)

## Functions

| Name | Summary |
|---|---|
| [onNotificationBtnClicked](on-notification-btn-clicked.md) | [androidJvm]<br>abstract fun [onNotificationBtnClicked](on-notification-btn-clicked.md)(btnNumber: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)) |
