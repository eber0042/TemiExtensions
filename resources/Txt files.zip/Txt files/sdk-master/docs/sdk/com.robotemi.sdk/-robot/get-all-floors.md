//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[getAllFloors](get-all-floors.md)

# getAllFloors

[androidJvm]\
fun [getAllFloors](get-all-floors.md)(): [List](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)&lt;[Floor](../../com.robotemi.sdk.map/-floor/index.md)&gt;
