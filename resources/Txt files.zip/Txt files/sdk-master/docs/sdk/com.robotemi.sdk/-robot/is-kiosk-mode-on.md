//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[isKioskModeOn](is-kiosk-mode-on.md)

# isKioskModeOn

[androidJvm]\

@CheckResult

fun [isKioskModeOn](is-kiosk-mode-on.md)(): [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)
