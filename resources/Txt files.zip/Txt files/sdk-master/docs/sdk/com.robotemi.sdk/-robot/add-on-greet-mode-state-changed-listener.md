//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addOnGreetModeStateChangedListener](add-on-greet-mode-state-changed-listener.md)

# addOnGreetModeStateChangedListener

[androidJvm]\

@UiThread

fun [addOnGreetModeStateChangedListener](add-on-greet-mode-state-changed-listener.md)(listener: [OnGreetModeStateChangedListener](../../com.robotemi.sdk.listeners/-on-greet-mode-state-changed-listener/index.md))
