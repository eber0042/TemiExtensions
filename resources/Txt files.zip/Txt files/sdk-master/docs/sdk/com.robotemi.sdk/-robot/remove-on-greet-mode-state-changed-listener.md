//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnGreetModeStateChangedListener](remove-on-greet-mode-state-changed-listener.md)

# removeOnGreetModeStateChangedListener

[androidJvm]\

@UiThread

fun [removeOnGreetModeStateChangedListener](remove-on-greet-mode-state-changed-listener.md)(listener: [OnGreetModeStateChangedListener](../../com.robotemi.sdk.listeners/-on-greet-mode-state-changed-listener/index.md))
