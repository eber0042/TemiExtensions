//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[setMediaPlaying](set-media-playing.md)

# setMediaPlaying

[androidJvm]\
~~fun~~ [~~setMediaPlaying~~](set-media-playing.md)~~(~~isPlaying: [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)~~)~~
