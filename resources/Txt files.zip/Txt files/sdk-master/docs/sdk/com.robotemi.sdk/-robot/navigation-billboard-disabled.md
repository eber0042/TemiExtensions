//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[navigationBillboardDisabled](navigation-billboard-disabled.md)

# navigationBillboardDisabled

[androidJvm]\

@get:[JvmName](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.jvm/-jvm-name/index.html)(name = &quot;isNavigationBillboardDisabled&quot;)

@get:CheckResult

val [navigationBillboardDisabled](navigation-billboard-disabled.md): [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)
