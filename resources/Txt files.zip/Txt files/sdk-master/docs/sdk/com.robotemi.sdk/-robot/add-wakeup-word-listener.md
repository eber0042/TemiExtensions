//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addWakeupWordListener](add-wakeup-word-listener.md)

# addWakeupWordListener

[androidJvm]\

@UiThread

fun [addWakeupWordListener](add-wakeup-word-listener.md)(wakeupWordListener: [Robot.WakeupWordListener](-wakeup-word-listener/index.md))
