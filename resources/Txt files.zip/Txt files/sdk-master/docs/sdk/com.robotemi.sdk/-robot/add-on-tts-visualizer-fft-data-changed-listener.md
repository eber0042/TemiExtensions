//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addOnTtsVisualizerFftDataChangedListener](add-on-tts-visualizer-fft-data-changed-listener.md)

# addOnTtsVisualizerFftDataChangedListener

[androidJvm]\

@UiThread

fun [addOnTtsVisualizerFftDataChangedListener](add-on-tts-visualizer-fft-data-changed-listener.md)(onTtsVisualizerFftDataChangedListener: [OnTtsVisualizerFftDataChangedListener](../../com.robotemi.sdk.listeners/-on-tts-visualizer-fft-data-changed-listener/index.md))
