//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeWakeupWordListener](remove-wakeup-word-listener.md)

# removeWakeupWordListener

[androidJvm]\

@UiThread

fun [removeWakeupWordListener](remove-wakeup-word-listener.md)(wakeupWordListener: [Robot.WakeupWordListener](-wakeup-word-listener/index.md))
