//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addOnTelepresenceEventChangedListener](add-on-telepresence-event-changed-listener.md)

# addOnTelepresenceEventChangedListener

[androidJvm]\

@UiThread

fun [addOnTelepresenceEventChangedListener](add-on-telepresence-event-changed-listener.md)(listener: [OnTelepresenceEventChangedListener](../../com.robotemi.sdk.listeners/-on-telepresence-event-changed-listener/index.md))
