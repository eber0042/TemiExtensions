//[sdk](../../../../index.md)/[com.robotemi.sdk](../../index.md)/[Robot](../index.md)/[MediaButtonListener](index.md)/[onBackButtonClicked](on-back-button-clicked.md)

# onBackButtonClicked

[androidJvm]\
abstract fun [onBackButtonClicked](on-back-button-clicked.md)()
