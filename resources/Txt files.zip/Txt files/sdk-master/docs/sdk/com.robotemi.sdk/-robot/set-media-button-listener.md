//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[setMediaButtonListener](set-media-button-listener.md)

# setMediaButtonListener

[androidJvm]\
fun [setMediaButtonListener](set-media-button-listener.md)(mediaButtonListener: [Robot.MediaButtonListener](-media-button-listener/index.md))
