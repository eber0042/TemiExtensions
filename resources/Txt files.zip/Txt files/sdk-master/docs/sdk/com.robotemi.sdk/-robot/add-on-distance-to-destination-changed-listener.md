//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addOnDistanceToDestinationChangedListener](add-on-distance-to-destination-changed-listener.md)

# addOnDistanceToDestinationChangedListener

[androidJvm]\

@UiThread

fun [addOnDistanceToDestinationChangedListener](add-on-distance-to-destination-changed-listener.md)(listener: [OnDistanceToDestinationChangedListener](../../com.robotemi.sdk.navigation.listener/-on-distance-to-destination-changed-listener/index.md))
