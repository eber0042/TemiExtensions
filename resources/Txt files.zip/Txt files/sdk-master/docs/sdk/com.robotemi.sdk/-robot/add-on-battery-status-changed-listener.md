//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addOnBatteryStatusChangedListener](add-on-battery-status-changed-listener.md)

# addOnBatteryStatusChangedListener

[androidJvm]\

@UiThread

fun [addOnBatteryStatusChangedListener](add-on-battery-status-changed-listener.md)(listener: [OnBatteryStatusChangedListener](../../com.robotemi.sdk.listeners/-on-battery-status-changed-listener/index.md))
