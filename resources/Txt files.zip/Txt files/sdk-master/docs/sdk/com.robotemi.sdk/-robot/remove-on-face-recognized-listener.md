//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnFaceRecognizedListener](remove-on-face-recognized-listener.md)

# removeOnFaceRecognizedListener

[androidJvm]\

@UiThread

fun [removeOnFaceRecognizedListener](remove-on-face-recognized-listener.md)(listener: [OnFaceRecognizedListener](../../com.robotemi.sdk.face/-on-face-recognized-listener/index.md))
