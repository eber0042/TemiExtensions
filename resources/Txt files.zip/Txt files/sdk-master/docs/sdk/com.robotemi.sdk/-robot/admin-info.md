//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[adminInfo](admin-info.md)

# adminInfo

[androidJvm]\

@get:CheckResult

val [adminInfo](admin-info.md): [UserInfo](../-user-info/index.md)?

Get the information of temi's admin.
