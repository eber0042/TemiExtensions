//[sdk](../../../../index.md)/[com.robotemi.sdk](../../index.md)/[Robot](../index.md)/[Companion](index.md)/[getInstance](get-instance.md)

# getInstance

[androidJvm]\

@[JvmStatic](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.jvm/-jvm-static/index.html)

fun [getInstance](get-instance.md)(): [Robot](../index.md)
