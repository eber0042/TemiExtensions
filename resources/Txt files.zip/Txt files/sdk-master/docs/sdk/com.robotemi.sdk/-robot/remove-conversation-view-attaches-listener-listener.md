//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeConversationViewAttachesListenerListener](remove-conversation-view-attaches-listener-listener.md)

# removeConversationViewAttachesListenerListener

[androidJvm]\

@UiThread

~~fun~~ [~~removeConversationViewAttachesListenerListener~~](remove-conversation-view-attaches-listener-listener.md)~~(~~conversationViewAttachesListener: [Robot.ConversationViewAttachesListener](-conversation-view-attaches-listener/index.md)~~)~~
