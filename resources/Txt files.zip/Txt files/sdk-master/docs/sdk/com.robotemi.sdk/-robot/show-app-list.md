//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[showAppList](show-app-list.md)

# showAppList

[androidJvm]\
fun [showAppList](show-app-list.md)()

Go to the App list of Launcher.
