//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeNlpListener](remove-nlp-listener.md)

# removeNlpListener

[androidJvm]\

@UiThread

fun [removeNlpListener](remove-nlp-listener.md)(nlpListener: [Robot.NlpListener](-nlp-listener/index.md))
