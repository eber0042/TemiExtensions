//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[autoReturnOn](auto-return-on.md)

# autoReturnOn

[androidJvm]\

@get:[JvmName](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.jvm/-jvm-name/index.html)(name = &quot;isAutoReturnOn&quot;)

@get:CheckResult

var [autoReturnOn](auto-return-on.md): [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)

Turn on/off auto return.
