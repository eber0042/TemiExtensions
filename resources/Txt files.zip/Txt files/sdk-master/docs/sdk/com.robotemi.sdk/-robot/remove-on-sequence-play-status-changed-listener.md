//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnSequencePlayStatusChangedListener](remove-on-sequence-play-status-changed-listener.md)

# removeOnSequencePlayStatusChangedListener

[androidJvm]\

@UiThread

fun [removeOnSequencePlayStatusChangedListener](remove-on-sequence-play-status-changed-listener.md)(listener: [OnSequencePlayStatusChangedListener](../../com.robotemi.sdk.sequence/-on-sequence-play-status-changed-listener/index.md))
