//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[releaseContexts](release-contexts.md)

# releaseContexts

[androidJvm]\
~~fun~~ [~~releaseContexts~~](release-contexts.md)~~(~~contextsToRelease: [List](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)&lt;[String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)&gt;~~)~~

Release previously locked contexts. See .lockContexts.

## Parameters

androidJvm

| | |
|---|---|
| contextsToRelease | -     List of contexts names to release. |
