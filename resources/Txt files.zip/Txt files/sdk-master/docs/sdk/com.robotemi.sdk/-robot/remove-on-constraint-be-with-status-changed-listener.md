//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnConstraintBeWithStatusChangedListener](remove-on-constraint-be-with-status-changed-listener.md)

# removeOnConstraintBeWithStatusChangedListener

[androidJvm]\

@UiThread

fun [removeOnConstraintBeWithStatusChangedListener](remove-on-constraint-be-with-status-changed-listener.md)(listener: [OnConstraintBeWithStatusChangedListener](../../com.robotemi.sdk.listeners/-on-constraint-be-with-status-changed-listener/index.md))
