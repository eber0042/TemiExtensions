//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[allContact](all-contact.md)

# allContact

[androidJvm]\

@get:CheckResult

val [allContact](all-contact.md): [List](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)&lt;[UserInfo](../-user-info/index.md)&gt;

Fetch all the temi contacts.
