//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[publishTtsStatus](publish-tts-status.md)

# publishTtsStatus

[androidJvm]\
fun [publishTtsStatus](publish-tts-status.md)(ttsRequest: [TtsRequest](../-tts-request/index.md))
