//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[enabledLatinKeyboards](enabled-latin-keyboards.md)

# enabledLatinKeyboards

[androidJvm]\
fun [enabledLatinKeyboards](enabled-latin-keyboards.md)(keyboards: [List](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)&lt;[String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)&gt;)

Enabled latin keyboards

## Parameters

androidJvm

| | |
|---|---|
| keyboards | should be from the keys of map by [getSupportedLatinKeyboards](get-supported-latin-keyboards.md)<br>And the first element will be the selected keyboard |
