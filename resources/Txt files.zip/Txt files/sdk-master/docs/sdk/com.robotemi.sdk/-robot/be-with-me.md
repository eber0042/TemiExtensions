//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[beWithMe](be-with-me.md)

# beWithMe

[androidJvm]\
fun [beWithMe](be-with-me.md)()

Request robot to follow user around. Add [OnBeWithMeStatusChangedListener](../../com.robotemi.sdk.listeners/-on-be-with-me-status-changed-listener/index.md) to listen for status changes.
