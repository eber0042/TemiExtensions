//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[setTtsService](set-tts-service.md)

# setTtsService

[androidJvm]\
fun [setTtsService](set-tts-service.md)(ttsService: [ITtsService](../../com.robotemi.sdk.voice/-i-tts-service/index.md)?)
