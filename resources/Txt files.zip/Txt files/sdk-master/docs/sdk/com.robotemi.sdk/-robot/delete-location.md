//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[deleteLocation](delete-location.md)

# deleteLocation

[androidJvm]\
fun [deleteLocation](delete-location.md)(name: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)): [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)

Delete location.

#### Return

Result of a successful or failed operation.

## Parameters

androidJvm

| | |
|---|---|
| name | Location name. |
