//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[getMapData](get-map-data.md)

# getMapData

[androidJvm]\

@Nullable

@WorkerThread

@CheckResult

fun [getMapData](get-map-data.md)(): [MapDataModel](../../com.robotemi.sdk.map/-map-data-model/index.md)?

Get map data.

#### Return

Map data.
