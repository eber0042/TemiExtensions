//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnDetectionStateChangedListener](remove-on-detection-state-changed-listener.md)

# removeOnDetectionStateChangedListener

[androidJvm]\

@UiThread

fun [removeOnDetectionStateChangedListener](remove-on-detection-state-changed-listener.md)(listener: [OnDetectionStateChangedListener](../../com.robotemi.sdk.listeners/-on-detection-state-changed-listener/index.md))
