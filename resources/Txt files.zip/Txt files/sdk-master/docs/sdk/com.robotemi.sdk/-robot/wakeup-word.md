//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[wakeupWord](wakeup-word.md)

# wakeupWord

[androidJvm]\

@get:CheckResult

val [wakeupWord](wakeup-word.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

The wakeup word of the temi's assistant.
