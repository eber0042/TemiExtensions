//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnDetectionDataChangedListener](remove-on-detection-data-changed-listener.md)

# removeOnDetectionDataChangedListener

[androidJvm]\

@UiThread

fun [removeOnDetectionDataChangedListener](remove-on-detection-data-changed-listener.md)(listener: [OnDetectionDataChangedListener](../../com.robotemi.sdk.listeners/-on-detection-data-changed-listener/index.md))
