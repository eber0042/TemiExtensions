//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[showAlertNotification](show-alert-notification.md)

# showAlertNotification

[androidJvm]\
fun [showAlertNotification](show-alert-notification.md)(notification: [AlertNotification](../../com.robotemi.sdk.notification/-alert-notification/index.md), notificationListener: [Robot.NotificationListener](-notification-listener/index.md))
