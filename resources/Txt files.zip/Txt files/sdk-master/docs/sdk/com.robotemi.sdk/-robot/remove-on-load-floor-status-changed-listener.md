//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnLoadFloorStatusChangedListener](remove-on-load-floor-status-changed-listener.md)

# removeOnLoadFloorStatusChangedListener

[androidJvm]\

@UiThread

fun [removeOnLoadFloorStatusChangedListener](remove-on-load-floor-status-changed-listener.md)(listener: [OnLoadFloorStatusChangedListener](../../com.robotemi.sdk.map/-on-load-floor-status-changed-listener/index.md))
