//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[recentCalls](recent-calls.md)

# recentCalls

[androidJvm]\

@get:CheckResult

val [recentCalls](recent-calls.md): [List](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)&lt;[RecentCallModel](../../com.robotemi.sdk.model/-recent-call-model/index.md)&gt;

Fetch recent calls.
