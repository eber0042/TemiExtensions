//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[finishConversation](finish-conversation.md)

# finishConversation

[androidJvm]\
fun [finishConversation](finish-conversation.md)()

Finish conversation.
