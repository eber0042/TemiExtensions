//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addOnTtsVisualizerWaveFormDataChangedListener](add-on-tts-visualizer-wave-form-data-changed-listener.md)

# addOnTtsVisualizerWaveFormDataChangedListener

[androidJvm]\

@UiThread

fun [addOnTtsVisualizerWaveFormDataChangedListener](add-on-tts-visualizer-wave-form-data-changed-listener.md)(onTtsVisualizerWaveFormDataChangedListener: [OnTtsVisualizerWaveFormDataChangedListener](../../com.robotemi.sdk.listeners/-on-tts-visualizer-wave-form-data-changed-listener/index.md))
