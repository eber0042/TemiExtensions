//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addOnMovementStatusChangedListener](add-on-movement-status-changed-listener.md)

# addOnMovementStatusChangedListener

[androidJvm]\

@UiThread

fun [addOnMovementStatusChangedListener](add-on-movement-status-changed-listener.md)(listener: [OnMovementStatusChangedListener](../../com.robotemi.sdk.listeners/-on-movement-status-changed-listener/index.md))
