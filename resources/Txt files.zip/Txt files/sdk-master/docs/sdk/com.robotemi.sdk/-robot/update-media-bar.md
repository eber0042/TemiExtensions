//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[updateMediaBar](update-media-bar.md)

# updateMediaBar

[androidJvm]\
~~fun~~ [~~updateMediaBar~~](update-media-bar.md)~~(~~mediaBarData: [MediaBarData](../../com.robotemi.sdk.mediabar/-media-bar-data/index.md)~~)~~
