//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[isSelectedKioskApp](is-selected-kiosk-app.md)

# isSelectedKioskApp

[androidJvm]\

@CheckResult

fun [isSelectedKioskApp](is-selected-kiosk-app.md)(): [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)

Whether this App is selected as the Kiosk Mode App.
