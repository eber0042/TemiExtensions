//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeConversationViewAttachesListener](remove-conversation-view-attaches-listener.md)

# removeConversationViewAttachesListener

[androidJvm]\

@UiThread

fun [removeConversationViewAttachesListener](remove-conversation-view-attaches-listener.md)(conversationViewAttachesListener: [Robot.ConversationViewAttachesListener](-conversation-view-attaches-listener/index.md))
