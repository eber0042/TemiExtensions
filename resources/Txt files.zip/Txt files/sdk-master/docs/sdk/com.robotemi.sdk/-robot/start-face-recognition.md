//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[startFaceRecognition](start-face-recognition.md)

# startFaceRecognition

[androidJvm]\
fun [startFaceRecognition](start-face-recognition.md)()

Start face recognition.
