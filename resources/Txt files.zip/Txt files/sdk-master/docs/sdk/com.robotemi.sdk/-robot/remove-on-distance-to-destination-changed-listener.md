//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnDistanceToDestinationChangedListener](remove-on-distance-to-destination-changed-listener.md)

# removeOnDistanceToDestinationChangedListener

[androidJvm]\

@UiThread

fun [removeOnDistanceToDestinationChangedListener](remove-on-distance-to-destination-changed-listener.md)(listener: [OnDistanceToDestinationChangedListener](../../com.robotemi.sdk.navigation.listener/-on-distance-to-destination-changed-listener/index.md))
