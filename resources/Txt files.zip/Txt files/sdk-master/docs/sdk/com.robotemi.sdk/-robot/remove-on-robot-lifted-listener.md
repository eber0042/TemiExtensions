//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnRobotLiftedListener](remove-on-robot-lifted-listener.md)

# removeOnRobotLiftedListener

[androidJvm]\

@UiThread

fun [removeOnRobotLiftedListener](remove-on-robot-lifted-listener.md)(listener: [OnRobotLiftedListener](../../com.robotemi.sdk.listeners/-on-robot-lifted-listener/index.md))
