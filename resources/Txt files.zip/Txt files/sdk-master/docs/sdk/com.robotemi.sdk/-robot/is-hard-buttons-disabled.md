//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[isHardButtonsDisabled](is-hard-buttons-disabled.md)

# isHardButtonsDisabled

[androidJvm]\

@get:CheckResult

var [isHardButtonsDisabled](is-hard-buttons-disabled.md): [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)

Get(Set) HardButtons enabled(disabled).
