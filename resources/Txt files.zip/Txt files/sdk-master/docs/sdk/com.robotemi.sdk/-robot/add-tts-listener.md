//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addTtsListener](add-tts-listener.md)

# addTtsListener

[androidJvm]\

@UiThread

fun [addTtsListener](add-tts-listener.md)(ttsListener: [Robot.TtsListener](-tts-listener/index.md))
