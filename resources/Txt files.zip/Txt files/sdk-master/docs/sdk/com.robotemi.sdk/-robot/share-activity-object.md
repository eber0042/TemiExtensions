//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[shareActivityObject](share-activity-object.md)

# shareActivityObject

[androidJvm]\
fun [shareActivityObject](share-activity-object.md)(activityStreamObject: [ActivityStreamObject](../../com.robotemi.sdk.activitystream/-activity-stream-object/index.md))
