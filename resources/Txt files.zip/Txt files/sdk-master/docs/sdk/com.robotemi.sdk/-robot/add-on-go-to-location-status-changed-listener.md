//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addOnGoToLocationStatusChangedListener](add-on-go-to-location-status-changed-listener.md)

# addOnGoToLocationStatusChangedListener

[androidJvm]\

@UiThread

fun [addOnGoToLocationStatusChangedListener](add-on-go-to-location-status-changed-listener.md)(listener: [OnGoToLocationStatusChangedListener](../../com.robotemi.sdk.listeners/-on-go-to-location-status-changed-listener/index.md))
