//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addOnConversationStatusChangedListener](add-on-conversation-status-changed-listener.md)

# addOnConversationStatusChangedListener

[androidJvm]\

@UiThread

fun [addOnConversationStatusChangedListener](add-on-conversation-status-changed-listener.md)(onConversationStatusChangedListener: [OnConversationStatusChangedListener](../../com.robotemi.sdk.listeners/-on-conversation-status-changed-listener/index.md))
