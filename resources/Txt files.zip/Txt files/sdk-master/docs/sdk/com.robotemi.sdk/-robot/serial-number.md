//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[serialNumber](serial-number.md)

# serialNumber

[androidJvm]\

@get:CheckResult

val [serialNumber](serial-number.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)?

Request robot's serial number as a String.

#### Return

The serial number of the robot.
