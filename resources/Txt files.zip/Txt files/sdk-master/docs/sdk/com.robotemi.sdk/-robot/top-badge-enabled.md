//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[topBadgeEnabled](top-badge-enabled.md)

# topBadgeEnabled

[androidJvm]\

@get:[JvmName](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.jvm/-jvm-name/index.html)(name = &quot;isTopBadgeEnabled&quot;)

@get:CheckResult

var [topBadgeEnabled](top-badge-enabled.md): [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)

Show or hide the green badge(Movement indicator such as navigation, follow...) at the top of the screen.
