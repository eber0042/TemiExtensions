//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[showNormalNotification](show-normal-notification.md)

# showNormalNotification

[androidJvm]\
fun [showNormalNotification](show-normal-notification.md)(notification: [NormalNotification](../../com.robotemi.sdk.notification/-normal-notification/index.md))
