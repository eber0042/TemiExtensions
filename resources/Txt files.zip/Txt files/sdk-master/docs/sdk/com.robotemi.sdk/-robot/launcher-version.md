//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[launcherVersion](launcher-version.md)

# launcherVersion

[androidJvm]\

@get:CheckResult

val [launcherVersion](launcher-version.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

Get version of the Launcher.
