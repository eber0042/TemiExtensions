//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeAsrListener](remove-asr-listener.md)

# removeAsrListener

[androidJvm]\

@UiThread

fun [removeAsrListener](remove-asr-listener.md)(asrListener: [Robot.AsrListener](-asr-listener/index.md))
