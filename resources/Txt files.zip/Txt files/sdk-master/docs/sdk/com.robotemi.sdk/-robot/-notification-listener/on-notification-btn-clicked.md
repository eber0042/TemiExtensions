//[sdk](../../../../index.md)/[com.robotemi.sdk](../../index.md)/[Robot](../index.md)/[NotificationListener](index.md)/[onNotificationBtnClicked](on-notification-btn-clicked.md)

# onNotificationBtnClicked

[androidJvm]\
abstract fun [onNotificationBtnClicked](on-notification-btn-clicked.md)(btnNumber: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html))
