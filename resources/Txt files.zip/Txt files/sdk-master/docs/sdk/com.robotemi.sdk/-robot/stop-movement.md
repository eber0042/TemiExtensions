//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[stopMovement](stop-movement.md)

# stopMovement

[androidJvm]\
fun [stopMovement](stop-movement.md)()

Request robot to stop any movement.
