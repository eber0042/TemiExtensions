//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addConversationViewAttachesListenerListener](add-conversation-view-attaches-listener-listener.md)

# addConversationViewAttachesListenerListener

[androidJvm]\

@UiThread

~~fun~~ [~~addConversationViewAttachesListenerListener~~](add-conversation-view-attaches-listener-listener.md)~~(~~conversationViewAttachesListener: [Robot.ConversationViewAttachesListener](-conversation-view-attaches-listener/index.md)~~)~~
