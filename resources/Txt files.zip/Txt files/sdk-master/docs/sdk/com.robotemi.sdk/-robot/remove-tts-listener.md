//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeTtsListener](remove-tts-listener.md)

# removeTtsListener

[androidJvm]\

@UiThread

fun [removeTtsListener](remove-tts-listener.md)(ttsListener: [Robot.TtsListener](-tts-listener/index.md))
