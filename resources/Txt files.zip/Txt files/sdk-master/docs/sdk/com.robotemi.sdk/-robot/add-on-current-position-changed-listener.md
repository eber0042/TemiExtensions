//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addOnCurrentPositionChangedListener](add-on-current-position-changed-listener.md)

# addOnCurrentPositionChangedListener

[androidJvm]\

@UiThread

fun [addOnCurrentPositionChangedListener](add-on-current-position-changed-listener.md)(listener: [OnCurrentPositionChangedListener](../../com.robotemi.sdk.navigation.listener/-on-current-position-changed-listener/index.md))
