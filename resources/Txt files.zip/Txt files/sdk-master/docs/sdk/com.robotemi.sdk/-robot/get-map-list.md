//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[getMapList](get-map-list.md)

# getMapList

[androidJvm]\

@WorkerThread

fun [getMapList](get-map-list.md)(): [List](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)&lt;[MapModel](../../com.robotemi.sdk.map/-map-model/index.md)&gt;

Get map list from server.

#### Return

Saved map
