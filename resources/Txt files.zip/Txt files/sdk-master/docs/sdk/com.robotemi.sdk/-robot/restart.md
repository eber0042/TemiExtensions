//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[restart](restart.md)

# restart

[androidJvm]\
fun [restart](restart.md)()

Restart temi.
