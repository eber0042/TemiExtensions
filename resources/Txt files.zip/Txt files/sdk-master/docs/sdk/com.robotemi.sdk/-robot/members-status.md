//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[membersStatus](members-status.md)

# membersStatus

[androidJvm]\

@get:CheckResult

val [membersStatus](members-status.md): [List](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)&lt;[MemberStatusModel](../../com.robotemi.sdk.model/-member-status-model/index.md)&gt;
