//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeMediaButtonListener](remove-media-button-listener.md)

# removeMediaButtonListener

[androidJvm]\
fun [removeMediaButtonListener](remove-media-button-listener.md)()
