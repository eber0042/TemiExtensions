//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnMovementStatusChangedListener](remove-on-movement-status-changed-listener.md)

# removeOnMovementStatusChangedListener

[androidJvm]\

@UiThread

fun [removeOnMovementStatusChangedListener](remove-on-movement-status-changed-listener.md)(listener: [OnMovementStatusChangedListener](../../com.robotemi.sdk.listeners/-on-movement-status-changed-listener/index.md))
