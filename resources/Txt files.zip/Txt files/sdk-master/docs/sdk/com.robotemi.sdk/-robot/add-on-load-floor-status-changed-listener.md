//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addOnLoadFloorStatusChangedListener](add-on-load-floor-status-changed-listener.md)

# addOnLoadFloorStatusChangedListener

[androidJvm]\

@UiThread

fun [addOnLoadFloorStatusChangedListener](add-on-load-floor-status-changed-listener.md)(listener: [OnLoadFloorStatusChangedListener](../../com.robotemi.sdk.map/-on-load-floor-status-changed-listener/index.md))
