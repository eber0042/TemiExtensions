//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[setActivityStreamPublishListener](set-activity-stream-publish-listener.md)

# setActivityStreamPublishListener

[androidJvm]\
fun [setActivityStreamPublishListener](set-activity-stream-publish-listener.md)(activityStreamPublishListener: [Robot.ActivityStreamPublishListener](-activity-stream-publish-listener/index.md)?)
