//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnUserInteractionChangedListener](remove-on-user-interaction-changed-listener.md)

# removeOnUserInteractionChangedListener

[androidJvm]\

@UiThread

fun [removeOnUserInteractionChangedListener](remove-on-user-interaction-changed-listener.md)(listener: [OnUserInteractionChangedListener](../../com.robotemi.sdk.listeners/-on-user-interaction-changed-listener/index.md))
