//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[requestToBeKioskApp](request-to-be-kiosk-app.md)

# requestToBeKioskApp

[androidJvm]\
fun [requestToBeKioskApp](request-to-be-kiosk-app.md)()

Request to be the selected Kiosk Mode App programmatically.
