//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[askQuestion](ask-question.md)

# askQuestion

[androidJvm]\
fun [askQuestion](ask-question.md)(question: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html))

Start a conversation.

## Parameters

androidJvm

| | |
|---|---|
| question | -     First question from robot. |
