//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[trackUserOn](track-user-on.md)

# trackUserOn

[androidJvm]\

@get:[JvmName](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.jvm/-jvm-name/index.html)(name = &quot;isTrackUserOn&quot;)

@get:CheckResult

var [trackUserOn](track-user-on.md): [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)

Turn on/off track user(welcome mode).
