//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addOnFaceRecognizedListener](add-on-face-recognized-listener.md)

# addOnFaceRecognizedListener

[androidJvm]\

@UiThread

fun [addOnFaceRecognizedListener](add-on-face-recognized-listener.md)(listener: [OnFaceRecognizedListener](../../com.robotemi.sdk.face/-on-face-recognized-listener/index.md))
