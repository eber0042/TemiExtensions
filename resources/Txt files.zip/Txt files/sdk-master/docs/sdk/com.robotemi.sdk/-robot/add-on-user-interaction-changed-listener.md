//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addOnUserInteractionChangedListener](add-on-user-interaction-changed-listener.md)

# addOnUserInteractionChangedListener

[androidJvm]\

@UiThread

fun [addOnUserInteractionChangedListener](add-on-user-interaction-changed-listener.md)(listener: [OnUserInteractionChangedListener](../../com.robotemi.sdk.listeners/-on-user-interaction-changed-listener/index.md))
