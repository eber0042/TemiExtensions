//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[batteryData](battery-data.md)

# batteryData

[androidJvm]\

@get:CheckResult

val [batteryData](battery-data.md): [BatteryData](../-battery-data/index.md)?

Request the robot to provide current battery status.

#### Return

The battery data of the robot.
