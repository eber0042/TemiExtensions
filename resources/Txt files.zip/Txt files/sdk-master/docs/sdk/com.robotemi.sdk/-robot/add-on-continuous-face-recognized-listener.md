//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addOnContinuousFaceRecognizedListener](add-on-continuous-face-recognized-listener.md)

# addOnContinuousFaceRecognizedListener

[androidJvm]\

@UiThread

fun [addOnContinuousFaceRecognizedListener](add-on-continuous-face-recognized-listener.md)(listener: [OnContinuousFaceRecognizedListener](../../com.robotemi.sdk.face/-on-continuous-face-recognized-listener/index.md))
