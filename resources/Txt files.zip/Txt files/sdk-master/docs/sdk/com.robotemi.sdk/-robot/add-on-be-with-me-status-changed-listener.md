//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addOnBeWithMeStatusChangedListener](add-on-be-with-me-status-changed-listener.md)

# addOnBeWithMeStatusChangedListener

[androidJvm]\

@UiThread

fun [addOnBeWithMeStatusChangedListener](add-on-be-with-me-status-changed-listener.md)(listener: [OnBeWithMeStatusChangedListener](../../com.robotemi.sdk.listeners/-on-be-with-me-status-changed-listener/index.md))
