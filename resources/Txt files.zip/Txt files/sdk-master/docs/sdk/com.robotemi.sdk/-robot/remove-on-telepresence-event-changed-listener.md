//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnTelepresenceEventChangedListener](remove-on-telepresence-event-changed-listener.md)

# removeOnTelepresenceEventChangedListener

[androidJvm]\

@UiThread

fun [removeOnTelepresenceEventChangedListener](remove-on-telepresence-event-changed-listener.md)(listener: [OnTelepresenceEventChangedListener](../../com.robotemi.sdk.listeners/-on-telepresence-event-changed-listener/index.md))
