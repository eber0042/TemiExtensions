//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[getCurrentFloor](get-current-floor.md)

# getCurrentFloor

[androidJvm]\
fun [getCurrentFloor](get-current-floor.md)(): [Floor](../../com.robotemi.sdk.map/-floor/index.md)?
