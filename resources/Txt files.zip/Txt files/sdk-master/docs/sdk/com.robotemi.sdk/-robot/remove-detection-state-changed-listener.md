//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeDetectionStateChangedListener](remove-detection-state-changed-listener.md)

# removeDetectionStateChangedListener

[androidJvm]\

@UiThread

~~fun~~ [~~removeDetectionStateChangedListener~~](remove-detection-state-changed-listener.md)~~(~~listener: [OnDetectionStateChangedListener](../../com.robotemi.sdk.listeners/-on-detection-state-changed-listener/index.md)~~)~~
