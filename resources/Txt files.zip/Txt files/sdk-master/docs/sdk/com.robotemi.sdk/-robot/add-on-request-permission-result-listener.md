//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addOnRequestPermissionResultListener](add-on-request-permission-result-listener.md)

# addOnRequestPermissionResultListener

[androidJvm]\

@UiThread

fun [addOnRequestPermissionResultListener](add-on-request-permission-result-listener.md)(listener: [OnRequestPermissionResultListener](../../com.robotemi.sdk.permission/-on-request-permission-result-listener/index.md))
