//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addOnUsersUpdatedListener](add-on-users-updated-listener.md)

# addOnUsersUpdatedListener

[androidJvm]\

@UiThread

fun [addOnUsersUpdatedListener](add-on-users-updated-listener.md)(listener: [OnUsersUpdatedListener](../../com.robotemi.sdk.listeners/-on-users-updated-listener/index.md))

Start listening for user information updates.

## Parameters

androidJvm

| | |
|---|---|
| listener | The listener you want to add. |
