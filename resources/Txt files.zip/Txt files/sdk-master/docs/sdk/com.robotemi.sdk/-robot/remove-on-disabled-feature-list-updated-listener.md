//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnDisabledFeatureListUpdatedListener](remove-on-disabled-feature-list-updated-listener.md)

# removeOnDisabledFeatureListUpdatedListener

[androidJvm]\

@UiThread

fun [removeOnDisabledFeatureListUpdatedListener](remove-on-disabled-feature-list-updated-listener.md)(listener: [OnDisabledFeatureListUpdatedListener](../../com.robotemi.sdk.listeners/-on-disabled-feature-list-updated-listener/index.md))
