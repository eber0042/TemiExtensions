//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addOnPrivacyModeStateChangedListener](add-on-privacy-mode-state-changed-listener.md)

# addOnPrivacyModeStateChangedListener

[androidJvm]\

@UiThread

fun [addOnPrivacyModeStateChangedListener](add-on-privacy-mode-state-changed-listener.md)(listener: [OnPrivacyModeChangedListener](../../com.robotemi.sdk.listeners/-on-privacy-mode-changed-listener/index.md))
