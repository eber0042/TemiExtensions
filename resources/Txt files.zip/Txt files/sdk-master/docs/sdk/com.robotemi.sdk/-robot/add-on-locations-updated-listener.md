//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addOnLocationsUpdatedListener](add-on-locations-updated-listener.md)

# addOnLocationsUpdatedListener

[androidJvm]\

@UiThread

fun [addOnLocationsUpdatedListener](add-on-locations-updated-listener.md)(listener: [OnLocationsUpdatedListener](../../com.robotemi.sdk.listeners/-on-locations-updated-listener/index.md))
