//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[addOnConstraintBeWithStatusChangedListener](add-on-constraint-be-with-status-changed-listener.md)

# addOnConstraintBeWithStatusChangedListener

[androidJvm]\

@UiThread

fun [addOnConstraintBeWithStatusChangedListener](add-on-constraint-be-with-status-changed-listener.md)(listener: [OnConstraintBeWithStatusChangedListener](../../com.robotemi.sdk.listeners/-on-constraint-be-with-status-changed-listener/index.md))
