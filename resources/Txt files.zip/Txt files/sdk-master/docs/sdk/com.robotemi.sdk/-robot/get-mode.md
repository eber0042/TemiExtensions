//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[getMode](get-mode.md)

# getMode

[androidJvm]\

@CheckResult

fun [getMode](get-mode.md)(): [Mode](../../com.robotemi.sdk.constants/-mode/index.md)

Get system mode.

#### Return

Default, Greet, Privacy
