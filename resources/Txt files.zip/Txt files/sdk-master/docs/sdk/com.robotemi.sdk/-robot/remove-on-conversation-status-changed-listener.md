//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnConversationStatusChangedListener](remove-on-conversation-status-changed-listener.md)

# removeOnConversationStatusChangedListener

[androidJvm]\

@UiThread

fun [removeOnConversationStatusChangedListener](remove-on-conversation-status-changed-listener.md)(onConversationStatusChangedListener: [OnConversationStatusChangedListener](../../com.robotemi.sdk.listeners/-on-conversation-status-changed-listener/index.md))
