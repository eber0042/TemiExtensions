//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[muteAlexa](mute-alexa.md)

# muteAlexa

[androidJvm]\
fun [muteAlexa](mute-alexa.md)()

Mute Alexa's MIC. Only useful in Global version with Alexa assistant。
