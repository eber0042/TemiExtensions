//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[Robot](index.md)/[removeOnGoToLocationStatusChangedListener](remove-on-go-to-location-status-changed-listener.md)

# removeOnGoToLocationStatusChangedListener

[androidJvm]\

@UiThread

fun [removeOnGoToLocationStatusChangedListener](remove-on-go-to-location-status-changed-listener.md)(listener: [OnGoToLocationStatusChangedListener](../../com.robotemi.sdk.listeners/-on-go-to-location-status-changed-listener/index.md))
