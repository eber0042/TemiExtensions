//[sdk](../../../../index.md)/[com.robotemi.sdk](../../index.md)/[Robot](../index.md)/[MediaButtonListener](index.md)

# MediaButtonListener

[androidJvm]\
interface [MediaButtonListener](index.md)

## Functions

| Name | Summary |
|---|---|
| [onBackButtonClicked](on-back-button-clicked.md) | [androidJvm]<br>abstract fun [onBackButtonClicked](on-back-button-clicked.md)() |
| [onNextButtonClicked](on-next-button-clicked.md) | [androidJvm]<br>abstract fun [onNextButtonClicked](on-next-button-clicked.md)() |
| [onPlayButtonClicked](on-play-button-clicked.md) | [androidJvm]<br>abstract fun [onPlayButtonClicked](on-play-button-clicked.md)(play: [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)) |
| [onTrackBarChanged](on-track-bar-changed.md) | [androidJvm]<br>abstract fun [onTrackBarChanged](on-track-bar-changed.md)(position: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)) |
