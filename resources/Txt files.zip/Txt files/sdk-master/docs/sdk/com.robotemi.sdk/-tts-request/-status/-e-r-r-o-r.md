[sdk](../../../index.md) / [com.robotemi.sdk](../../index.md) / [TtsRequest](../index.md) / [Status](index.md) / [ERROR](./-e-r-r-o-r.md)

# ERROR

`ERROR`