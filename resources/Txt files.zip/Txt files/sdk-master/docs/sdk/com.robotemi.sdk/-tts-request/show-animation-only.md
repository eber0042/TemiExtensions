//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[TtsRequest](index.md)/[showAnimationOnly](show-animation-only.md)

# showAnimationOnly

[androidJvm]\
val [showAnimationOnly](show-animation-only.md): [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html) = false
