//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[TtsRequest](index.md)/[TtsRequest](-tts-request.md)

# TtsRequest

[androidJvm]\
fun [TtsRequest](-tts-request.md)(source: Parcel)

fun [TtsRequest](-tts-request.md)(id: [UUID](https://docs.oracle.com/javase/8/docs/api/java/util/UUID.html) = UUID.randomUUID(), speech: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html), packageName: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) = &quot;&quot;, status: [TtsRequest.Status](-status/index.md) = Status.PENDING, drawableBitmap: Bitmap? = null, isShowOnConversationLayer: [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html), language: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 0, showAnimationOnly: [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html) = false)
