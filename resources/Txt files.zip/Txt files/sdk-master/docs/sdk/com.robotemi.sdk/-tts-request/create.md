[sdk](../../index.md) / [com.robotemi.sdk](../index.md) / [TtsRequest](index.md) / [create](./create.md)

# create

`@JvmOverloads @JvmStatic fun create(speech: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, isShowOnConversationLayer: `[`Boolean`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)` = true, language: `[`TtsRequest.Language`](-language/index.md)` = Language.SYSTEM, showAnimationOnly: `[`Boolean`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)` = false): `[`TtsRequest`](index.md)