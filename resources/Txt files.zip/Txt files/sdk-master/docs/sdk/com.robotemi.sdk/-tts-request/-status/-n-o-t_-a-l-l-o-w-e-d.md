[sdk](../../../index.md) / [com.robotemi.sdk](../../index.md) / [TtsRequest](../index.md) / [Status](index.md) / [NOT_ALLOWED](./-n-o-t_-a-l-l-o-w-e-d.md)

# NOT_ALLOWED

`NOT_ALLOWED`