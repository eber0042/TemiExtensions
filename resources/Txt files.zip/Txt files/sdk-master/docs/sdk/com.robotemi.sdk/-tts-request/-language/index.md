//[sdk](../../../../index.md)/[com.robotemi.sdk](../../index.md)/[TtsRequest](../index.md)/[Language](index.md)

# Language

[androidJvm]\
enum [Language](index.md) : [Enum](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-enum/index.html)&lt;[TtsRequest.Language](index.md)&gt;

## Entries

| | |
|---|---|
| [SYSTEM](-s-y-s-t-e-m/index.md) | [androidJvm]<br>[SYSTEM](-s-y-s-t-e-m/index.md) |
| [EN_US](-e-n_-u-s/index.md) | [androidJvm]<br>[EN_US](-e-n_-u-s/index.md) |
| [ZH_CN](-z-h_-c-n/index.md) | [androidJvm]<br>[ZH_CN](-z-h_-c-n/index.md) |
| [ZH_HK](-z-h_-h-k/index.md) | [androidJvm]<br>[ZH_HK](-z-h_-h-k/index.md) |
| [ZH_TW](-z-h_-t-w/index.md) | [androidJvm]<br>[ZH_TW](-z-h_-t-w/index.md) |
| [TH_TH](-t-h_-t-h/index.md) | [androidJvm]<br>[TH_TH](-t-h_-t-h/index.md) |
| [HE_IL](-h-e_-i-l/index.md) | [androidJvm]<br>[HE_IL](-h-e_-i-l/index.md) |
| [KO_KR](-k-o_-k-r/index.md) | [androidJvm]<br>[KO_KR](-k-o_-k-r/index.md) |
| [JA_JP](-j-a_-j-p/index.md) | [androidJvm]<br>[JA_JP](-j-a_-j-p/index.md) |
| [IN_ID](-i-n_-i-d/index.md) | [androidJvm]<br>[IN_ID](-i-n_-i-d/index.md) |
| [ID_ID](-i-d_-i-d/index.md) | [androidJvm]<br>[ID_ID](-i-d_-i-d/index.md) |
| [DE_DE](-d-e_-d-e/index.md) | [androidJvm]<br>[DE_DE](-d-e_-d-e/index.md) |
| [FR_FR](-f-r_-f-r/index.md) | [androidJvm]<br>[FR_FR](-f-r_-f-r/index.md) |
| [FR_CA](-f-r_-c-a/index.md) | [androidJvm]<br>[FR_CA](-f-r_-c-a/index.md) |
| [PT_BR](-p-t_-b-r/index.md) | [androidJvm]<br>[PT_BR](-p-t_-b-r/index.md) |
| [AR_EG](-a-r_-e-g/index.md) | [androidJvm]<br>[AR_EG](-a-r_-e-g/index.md) |
| [AR_AE](-a-r_-a-e/index.md) | [androidJvm]<br>[AR_AE](-a-r_-a-e/index.md) |
| [AR_XA](-a-r_-x-a/index.md) | [androidJvm]<br>[AR_XA](-a-r_-x-a/index.md) |
| [RU_RU](-r-u_-r-u/index.md) | [androidJvm]<br>[RU_RU](-r-u_-r-u/index.md) |
| [IT_IT](-i-t_-i-t/index.md) | [androidJvm]<br>[IT_IT](-i-t_-i-t/index.md) |
| [PL_PL](-p-l_-p-l/index.md) | [androidJvm]<br>[PL_PL](-p-l_-p-l/index.md) |
| [ES_ES](-e-s_-e-s/index.md) | [androidJvm]<br>[ES_ES](-e-s_-e-s/index.md) |

## Types

| Name | Summary |
|---|---|
| [Companion](-companion/index.md) | [androidJvm]<br>object [Companion](-companion/index.md) |

## Properties

| Name | Summary |
|---|---|
| [name](../../../com.robotemi.sdk.permission/-permission/-u-n-k-n-o-w-n/index.md#-372974862%2FProperties%2F462465411) | [androidJvm]<br>val [name](../../../com.robotemi.sdk.permission/-permission/-u-n-k-n-o-w-n/index.md#-372974862%2FProperties%2F462465411): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [ordinal](../../../com.robotemi.sdk.permission/-permission/-u-n-k-n-o-w-n/index.md#-739389684%2FProperties%2F462465411) | [androidJvm]<br>val [ordinal](../../../com.robotemi.sdk.permission/-permission/-u-n-k-n-o-w-n/index.md#-739389684%2FProperties%2F462465411): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
| [value](value.md) | [androidJvm]<br>val [value](value.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
