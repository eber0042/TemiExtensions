[sdk](../../../index.md) / [com.robotemi.sdk](../../index.md) / [TtsRequest](../index.md) / [Language](index.md) / [PT_BR](./-p-t_-b-r.md)

# PT_BR

`PT_BR`

### Inherited Properties

| Name | Summary |
|---|---|
| [value](value.md) | `val value: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
