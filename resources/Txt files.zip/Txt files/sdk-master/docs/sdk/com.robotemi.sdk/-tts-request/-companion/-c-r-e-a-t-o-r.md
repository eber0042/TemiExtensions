//[sdk](../../../../index.md)/[com.robotemi.sdk](../../index.md)/[TtsRequest](../index.md)/[Companion](index.md)/[CREATOR](-c-r-e-a-t-o-r.md)

# CREATOR

[androidJvm]\

@[JvmField](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.jvm/-jvm-field/index.html)

val [CREATOR](-c-r-e-a-t-o-r.md): Parcelable.Creator&lt;[TtsRequest](../index.md)&gt;
