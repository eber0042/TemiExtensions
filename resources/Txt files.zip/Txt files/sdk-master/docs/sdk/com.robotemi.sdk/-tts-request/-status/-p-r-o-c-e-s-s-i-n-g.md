[sdk](../../../index.md) / [com.robotemi.sdk](../../index.md) / [TtsRequest](../index.md) / [Status](index.md) / [PROCESSING](./-p-r-o-c-e-s-s-i-n-g.md)

# PROCESSING

`PROCESSING`