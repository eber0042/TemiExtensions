//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[TtsRequest](index.md)/[isShowOnConversationLayer](is-show-on-conversation-layer.md)

# isShowOnConversationLayer

[androidJvm]\
val [isShowOnConversationLayer](is-show-on-conversation-layer.md): [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)
