[sdk](../../index.md) / [com.robotemi.sdk](../index.md) / [TtsRequest](index.md) / [toString](./to-string.md)

# toString

`fun toString(): `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)