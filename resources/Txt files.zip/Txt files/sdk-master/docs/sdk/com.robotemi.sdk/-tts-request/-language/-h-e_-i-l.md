[sdk](../../../index.md) / [com.robotemi.sdk](../../index.md) / [TtsRequest](../index.md) / [Language](index.md) / [HE_IL](./-h-e_-i-l.md)

# HE_IL

`HE_IL`

### Inherited Properties

| Name | Summary |
|---|---|
| [value](value.md) | `val value: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
