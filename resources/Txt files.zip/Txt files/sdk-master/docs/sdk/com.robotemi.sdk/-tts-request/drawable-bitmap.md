//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[TtsRequest](index.md)/[drawableBitmap](drawable-bitmap.md)

# drawableBitmap

[androidJvm]\
val [drawableBitmap](drawable-bitmap.md): Bitmap? = null
