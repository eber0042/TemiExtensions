[sdk](../../../index.md) / [com.robotemi.sdk](../../index.md) / [TtsRequest](../index.md) / [Status](index.md) / [PENDING](./-p-e-n-d-i-n-g.md)

# PENDING

`PENDING`