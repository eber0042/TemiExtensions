[sdk](../../index.md) / [com.robotemi.sdk](../index.md) / [TtsRequest](index.md) / [CREATOR](./-c-r-e-a-t-o-r.md)

# CREATOR

`val CREATOR: `[`Creator`](https://developer.android.com/reference/android/os/Parcelable/Creator.html)`<`[`TtsRequest`](index.md)`>`