//[sdk](../../../../index.md)/[com.robotemi.sdk](../../index.md)/[TtsRequest](../index.md)/[Language](index.md)/[value](value.md)

# value

[androidJvm]\
val [value](value.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)
