[sdk](../../../index.md) / [com.robotemi.sdk](../../index.md) / [TtsRequest](../index.md) / [Status](index.md) / [STARTED](./-s-t-a-r-t-e-d.md)

# STARTED

`STARTED`