[sdk](../../../index.md) / [com.robotemi.sdk](../../index.md) / [TtsRequest](../index.md) / [Status](index.md) / [COMPLETED](./-c-o-m-p-l-e-t-e-d.md)

# COMPLETED

`COMPLETED`