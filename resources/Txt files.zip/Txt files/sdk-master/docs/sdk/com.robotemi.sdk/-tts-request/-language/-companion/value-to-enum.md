//[sdk](../../../../../index.md)/[com.robotemi.sdk](../../../index.md)/[TtsRequest](../../index.md)/[Language](../index.md)/[Companion](index.md)/[valueToEnum](value-to-enum.md)

# valueToEnum

[androidJvm]\

@[JvmStatic](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.jvm/-jvm-static/index.html)

fun [valueToEnum](value-to-enum.md)(value: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)): [TtsRequest.Language](../index.md)
