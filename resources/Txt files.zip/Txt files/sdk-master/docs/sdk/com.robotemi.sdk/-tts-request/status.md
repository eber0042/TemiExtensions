//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[TtsRequest](index.md)/[status](status.md)

# status

[androidJvm]\
var [status](status.md): [TtsRequest.Status](-status/index.md)
