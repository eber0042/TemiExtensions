[sdk](../../../index.md) / [com.robotemi.sdk](../../index.md) / [TtsRequest](../index.md) / [Status](index.md) / [CANCELED](./-c-a-n-c-e-l-e-d.md)

# CANCELED

`CANCELED`