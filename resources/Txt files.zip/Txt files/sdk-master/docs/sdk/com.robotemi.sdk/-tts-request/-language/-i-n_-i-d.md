[sdk](../../../index.md) / [com.robotemi.sdk](../../index.md) / [TtsRequest](../index.md) / [Language](index.md) / [IN_ID](./-i-n_-i-d.md)

# IN_ID

`IN_ID`

### Inherited Properties

| Name | Summary |
|---|---|
| [value](value.md) | `val value: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
