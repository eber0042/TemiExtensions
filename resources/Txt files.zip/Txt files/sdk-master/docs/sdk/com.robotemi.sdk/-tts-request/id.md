//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[TtsRequest](index.md)/[id](id.md)

# id

[androidJvm]\
val [id](id.md): [UUID](https://docs.oracle.com/javase/8/docs/api/java/util/UUID.html)
