//[sdk](../../../../index.md)/[com.robotemi.sdk](../../index.md)/[TtsRequest](../index.md)/[Companion](index.md)/[create](create.md)

# create

[androidJvm]\

@[JvmOverloads](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.jvm/-jvm-overloads/index.html)

@[JvmStatic](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.jvm/-jvm-static/index.html)

fun [create](create.md)(speech: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html), isShowOnConversationLayer: [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html) = true, language: [TtsRequest.Language](../-language/index.md) = Language.SYSTEM, showAnimationOnly: [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html) = false): [TtsRequest](../index.md)
