//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[TtsRequest](index.md)/[packageName](package-name.md)

# packageName

[androidJvm]\
var [packageName](package-name.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
