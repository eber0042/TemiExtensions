//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[TtsRequest](index.md)/[speech](speech.md)

# speech

[androidJvm]\
val [speech](speech.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
