[sdk](../../../index.md) / [com.robotemi.sdk](../../index.md) / [TtsRequest](../index.md) / [Language](index.md) / [AR_XA](./-a-r_-x-a.md)

# AR_XA

`AR_XA`

### Inherited Properties

| Name | Summary |
|---|---|
| [value](value.md) | `val value: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
