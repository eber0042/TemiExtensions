//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[UserInfo](index.md)/[userId](user-id.md)

# userId

[androidJvm]\
val [userId](user-id.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
