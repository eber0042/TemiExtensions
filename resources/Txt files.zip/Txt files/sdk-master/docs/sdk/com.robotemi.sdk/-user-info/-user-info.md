//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[UserInfo](index.md)/[UserInfo](-user-info.md)

# UserInfo

[androidJvm]\
fun [UserInfo](-user-info.md)(parcel: Parcel)

fun [UserInfo](-user-info.md)(userId: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html), name: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html), picUrl: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)? = &quot;&quot;, role: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html))
