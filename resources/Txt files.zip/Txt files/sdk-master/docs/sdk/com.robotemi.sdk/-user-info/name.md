//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[UserInfo](index.md)/[name](name.md)

# name

[androidJvm]\
val [name](name.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
