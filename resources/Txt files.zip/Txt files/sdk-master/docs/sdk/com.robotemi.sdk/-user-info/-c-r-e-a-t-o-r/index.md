//[sdk](../../../../index.md)/[com.robotemi.sdk](../../index.md)/[UserInfo](../index.md)/[CREATOR](index.md)

# CREATOR

[androidJvm]\
object [CREATOR](index.md) : Parcelable.Creator&lt;[UserInfo](../index.md)&gt;

## Functions

| Name | Summary |
|---|---|
| [createFromParcel](create-from-parcel.md) | [androidJvm]<br>open override fun [createFromParcel](create-from-parcel.md)(parcel: Parcel): [UserInfo](../index.md) |
| [newArray](new-array.md) | [androidJvm]<br>open override fun [newArray](new-array.md)(size: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)): [Array](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-array/index.html)&lt;[UserInfo](../index.md)?&gt; |
