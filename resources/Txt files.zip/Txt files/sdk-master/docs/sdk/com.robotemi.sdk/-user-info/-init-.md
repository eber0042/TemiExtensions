[sdk](../../index.md) / [com.robotemi.sdk](../index.md) / [UserInfo](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`UserInfo(parcel: `[`Parcel`](https://developer.android.com/reference/android/os/Parcel.html)`)`
`UserInfo(userId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, name: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, picUrl: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`? = "", role: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`)`