[sdk](../../index.md) / [com.robotemi.sdk](../index.md) / [UserInfo](index.md) / [newArray](./new-array.md)

# newArray

`fun newArray(size: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`): `[`Array`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-array/index.html)`<`[`UserInfo`](index.md)`?>`