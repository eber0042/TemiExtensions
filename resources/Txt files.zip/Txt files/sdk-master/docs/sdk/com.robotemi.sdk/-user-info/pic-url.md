//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[UserInfo](index.md)/[picUrl](pic-url.md)

# picUrl

[androidJvm]\
val [picUrl](pic-url.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)?
