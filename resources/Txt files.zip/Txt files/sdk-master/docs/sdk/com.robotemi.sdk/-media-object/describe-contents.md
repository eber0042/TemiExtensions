//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[MediaObject](index.md)/[describeContents](describe-contents.md)

# describeContents

[androidJvm]\
open fun [describeContents](describe-contents.md)(): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)
