//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[MediaObject](index.md)/[CREATOR](-c-r-e-a-t-o-r.md)

# CREATOR

[androidJvm]\
val [CREATOR](-c-r-e-a-t-o-r.md): Parcelable.Creator&lt;[MediaObject](index.md)&gt;
