//[sdk](../../../../../index.md)/[com.robotemi.sdk](../../../index.md)/[MediaObject](../../index.md)/[MimeType](../index.md)/[NONE](index.md)

# NONE

[androidJvm]\
[NONE](index.md)
