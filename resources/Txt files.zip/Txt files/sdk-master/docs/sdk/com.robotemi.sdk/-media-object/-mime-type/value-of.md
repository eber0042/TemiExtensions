//[sdk](../../../../index.md)/[com.robotemi.sdk](../../index.md)/[MediaObject](../index.md)/[MimeType](index.md)/[valueOf](value-of.md)

# valueOf

[androidJvm]\
open fun [valueOf](value-of.md)(name: [String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html)): [MediaObject.MimeType](index.md)
