//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[MediaObject](index.md)/[setMediaUri](set-media-uri.md)

# setMediaUri

[androidJvm]\
open fun [setMediaUri](set-media-uri.md)(uri: [String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html))
