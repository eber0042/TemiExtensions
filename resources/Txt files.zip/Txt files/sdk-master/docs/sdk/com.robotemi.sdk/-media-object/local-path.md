//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[MediaObject](index.md)/[localPath](local-path.md)

# localPath

[androidJvm]\

@get:NonNull

open val [localPath](local-path.md): [String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html)
