[sdk](../../../index.md) / [com.robotemi.sdk](../../index.md) / [MediaObject](../index.md) / [MimeType](index.md) / [GIF](./-g-i-f.md)

# GIF

`GIF`