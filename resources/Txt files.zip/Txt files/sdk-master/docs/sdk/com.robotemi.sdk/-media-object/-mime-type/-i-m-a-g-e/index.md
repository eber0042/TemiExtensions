//[sdk](../../../../../index.md)/[com.robotemi.sdk](../../../index.md)/[MediaObject](../../index.md)/[MimeType](../index.md)/[IMAGE](index.md)

# IMAGE

[androidJvm]\
[IMAGE](index.md)
