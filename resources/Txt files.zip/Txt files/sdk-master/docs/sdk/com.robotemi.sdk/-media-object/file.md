//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[MediaObject](index.md)/[file](file.md)

# file

[androidJvm]\
open val [file](file.md): [File](https://docs.oracle.com/javase/8/docs/api/java/io/File.html)
