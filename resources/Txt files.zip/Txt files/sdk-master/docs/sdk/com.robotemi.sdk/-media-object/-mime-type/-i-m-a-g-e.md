[sdk](../../../index.md) / [com.robotemi.sdk](../../index.md) / [MediaObject](../index.md) / [MimeType](index.md) / [IMAGE](./-i-m-a-g-e.md)

# IMAGE

`IMAGE`