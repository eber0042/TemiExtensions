//[sdk](../../../../../index.md)/[com.robotemi.sdk](../../../index.md)/[MediaObject](../../index.md)/[MimeType](../index.md)/[GIF](index.md)

# GIF

[androidJvm]\
[GIF](index.md)
