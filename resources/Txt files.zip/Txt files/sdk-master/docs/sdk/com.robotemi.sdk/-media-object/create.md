//[sdk](../../../index.md)/[com.robotemi.sdk](../index.md)/[MediaObject](index.md)/[create](create.md)

# create

[androidJvm]\
open fun [create](create.md)(mimeType: [MediaObject.MimeType](-mime-type/index.md), file: [File](https://docs.oracle.com/javase/8/docs/api/java/io/File.html)): [MediaObject](index.md)
