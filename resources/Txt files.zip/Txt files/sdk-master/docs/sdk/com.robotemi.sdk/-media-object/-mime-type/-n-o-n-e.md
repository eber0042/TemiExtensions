[sdk](../../../index.md) / [com.robotemi.sdk](../../index.md) / [MediaObject](../index.md) / [MimeType](index.md) / [NONE](./-n-o-n-e.md)

# NONE

`NONE`