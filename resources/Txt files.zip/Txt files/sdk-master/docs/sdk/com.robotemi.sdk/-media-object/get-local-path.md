[sdk](../../index.md) / [com.robotemi.sdk](../index.md) / [MediaObject](index.md) / [getLocalPath](./get-local-path.md)

# getLocalPath

`@NonNull open fun getLocalPath(): `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

Overrides [MediaContainer.getLocalPath](../-media-container/get-local-path.md)

