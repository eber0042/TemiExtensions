[sdk](../../../index.md) / [com.robotemi.sdk](../../index.md) / [MediaObject](../index.md) / [MimeType](index.md) / [VIDEO](./-v-i-d-e-o.md)

# VIDEO

`VIDEO`