//[sdk](../../../../index.md)/[com.robotemi.sdk](../../index.md)/[MediaObject](../index.md)/[MimeType](index.md)/[values](values.md)

# values

[androidJvm]\
open fun [values](values.md)(): [Array](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-array/index.html)&lt;[MediaObject.MimeType](index.md)&gt;
