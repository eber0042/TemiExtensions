[sdk](../../index.md) / [com.robotemi.sdk](../index.md) / [MediaObject](index.md) / [getMimeType](./get-mime-type.md)

# getMimeType

`open fun getMimeType(): `[`MediaObject.MimeType`](-mime-type/index.md)`!`

Overrides [MediaContainer.getMimeType](../-media-container/get-mime-type.md)

