[sdk](../../index.md) / [com.robotemi.sdk.constants](../index.md) / [ContentType](index.md) / [FACE_RECOGNITION_IMAGE](./-f-a-c-e_-r-e-c-o-g-n-i-t-i-o-n_-i-m-a-g-e.md)

# FACE_RECOGNITION_IMAGE

`FACE_RECOGNITION_IMAGE`

### Inherited Properties

| Name | Summary |
|---|---|
| [path](path.md) | `val path: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
