[sdk](../../../index.md) / [com.robotemi.sdk.constants](../../index.md) / [HardButton](../index.md) / [Mode](index.md) / [MAIN_BLOCK_FOLLOW](./-m-a-i-n_-b-l-o-c-k_-f-o-l-l-o-w.md)

# MAIN_BLOCK_FOLLOW

`MAIN_BLOCK_FOLLOW`

### Inherited Properties

| Name | Summary |
|---|---|
| [value](value.md) | `val value: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
