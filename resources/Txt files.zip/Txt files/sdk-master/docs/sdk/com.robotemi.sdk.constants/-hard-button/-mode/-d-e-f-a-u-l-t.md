[sdk](../../../index.md) / [com.robotemi.sdk.constants](../../index.md) / [HardButton](../index.md) / [Mode](index.md) / [DEFAULT](./-d-e-f-a-u-l-t.md)

# DEFAULT

`val DEFAULT: `[`HardButton.Mode`](index.md)