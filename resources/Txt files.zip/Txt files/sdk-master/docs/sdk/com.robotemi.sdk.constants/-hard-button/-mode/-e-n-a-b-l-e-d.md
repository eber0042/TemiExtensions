[sdk](../../../index.md) / [com.robotemi.sdk.constants](../../index.md) / [HardButton](../index.md) / [Mode](index.md) / [ENABLED](./-e-n-a-b-l-e-d.md)

# ENABLED

`ENABLED`

### Inherited Properties

| Name | Summary |
|---|---|
| [value](value.md) | `val value: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
