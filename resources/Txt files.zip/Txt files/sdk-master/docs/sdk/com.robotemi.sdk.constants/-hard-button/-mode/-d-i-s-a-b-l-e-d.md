[sdk](../../../index.md) / [com.robotemi.sdk.constants](../../index.md) / [HardButton](../index.md) / [Mode](index.md) / [DISABLED](./-d-i-s-a-b-l-e-d.md)

# DISABLED

`DISABLED`

### Inherited Properties

| Name | Summary |
|---|---|
| [value](value.md) | `val value: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
