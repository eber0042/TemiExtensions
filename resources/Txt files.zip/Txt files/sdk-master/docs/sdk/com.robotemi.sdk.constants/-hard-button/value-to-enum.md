[sdk](../../index.md) / [com.robotemi.sdk.constants](../index.md) / [HardButton](index.md) / [valueToEnum](./value-to-enum.md)

# valueToEnum

`@JvmStatic fun valueToEnum(value: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`? = 1): `[`HardButton`](index.md)