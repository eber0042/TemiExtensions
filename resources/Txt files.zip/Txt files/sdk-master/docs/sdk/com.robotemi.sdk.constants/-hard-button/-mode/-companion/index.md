//[sdk](../../../../../index.md)/[com.robotemi.sdk.constants](../../../index.md)/[HardButton](../../index.md)/[Mode](../index.md)/[Companion](index.md)

# Companion

[androidJvm]\
object [Companion](index.md)

## Functions

| Name | Summary |
|---|---|
| [valueToEnum](value-to-enum.md) | [androidJvm]<br>@[JvmStatic](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.jvm/-jvm-static/index.html)<br>fun [valueToEnum](value-to-enum.md)(value: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)? = 0): [HardButton.Mode](../index.md) |

## Properties

| Name | Summary |
|---|---|
| [DEFAULT](-d-e-f-a-u-l-t.md) | [androidJvm]<br>@[JvmField](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.jvm/-jvm-field/index.html)<br>val [DEFAULT](-d-e-f-a-u-l-t.md): [HardButton.Mode](../index.md) |
