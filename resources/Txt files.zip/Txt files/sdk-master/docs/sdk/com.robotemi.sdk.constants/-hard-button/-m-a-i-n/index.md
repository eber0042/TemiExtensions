//[sdk](../../../../index.md)/[com.robotemi.sdk.constants](../../index.md)/[HardButton](../index.md)/[MAIN](index.md)

# MAIN

[androidJvm]\
[MAIN](index.md)

## Properties

| Name | Summary |
|---|---|
| [name](../../../com.robotemi.sdk.permission/-permission/-u-n-k-n-o-w-n/index.md#-372974862%2FProperties%2F462465411) | [androidJvm]<br>val [name](../../../com.robotemi.sdk.permission/-permission/-u-n-k-n-o-w-n/index.md#-372974862%2FProperties%2F462465411): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [ordinal](../../../com.robotemi.sdk.permission/-permission/-u-n-k-n-o-w-n/index.md#-739389684%2FProperties%2F462465411) | [androidJvm]<br>val [ordinal](../../../com.robotemi.sdk.permission/-permission/-u-n-k-n-o-w-n/index.md#-739389684%2FProperties%2F462465411): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
| [value](../value.md) | [androidJvm]<br>val [value](../value.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
