//[sdk](../../../../index.md)/[com.robotemi.sdk.constants](../../index.md)/[HardButton](../index.md)/[Mode](index.md)

# Mode

[androidJvm]\
enum [Mode](index.md) : [Enum](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-enum/index.html)&lt;[HardButton.Mode](index.md)&gt;

## Entries

| | |
|---|---|
| [ENABLED](-e-n-a-b-l-e-d/index.md) | [androidJvm]<br>[ENABLED](-e-n-a-b-l-e-d/index.md) |
| [DISABLED](-d-i-s-a-b-l-e-d/index.md) | [androidJvm]<br>[DISABLED](-d-i-s-a-b-l-e-d/index.md) |
| [MAIN_BLOCK_FOLLOW](-m-a-i-n_-b-l-o-c-k_-f-o-l-l-o-w/index.md) | [androidJvm]<br>[MAIN_BLOCK_FOLLOW](-m-a-i-n_-b-l-o-c-k_-f-o-l-l-o-w/index.md) |

## Types

| Name | Summary |
|---|---|
| [Companion](-companion/index.md) | [androidJvm]<br>object [Companion](-companion/index.md) |

## Properties

| Name | Summary |
|---|---|
| [name](../../../com.robotemi.sdk.permission/-permission/-u-n-k-n-o-w-n/index.md#-372974862%2FProperties%2F462465411) | [androidJvm]<br>val [name](../../../com.robotemi.sdk.permission/-permission/-u-n-k-n-o-w-n/index.md#-372974862%2FProperties%2F462465411): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [ordinal](../../../com.robotemi.sdk.permission/-permission/-u-n-k-n-o-w-n/index.md#-739389684%2FProperties%2F462465411) | [androidJvm]<br>val [ordinal](../../../com.robotemi.sdk.permission/-permission/-u-n-k-n-o-w-n/index.md#-739389684%2FProperties%2F462465411): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
| [value](value.md) | [androidJvm]<br>val [value](value.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
