//[sdk](../../../../index.md)/[com.robotemi.sdk.constants](../../index.md)/[HardButton](../index.md)/[Companion](index.md)

# Companion

[androidJvm]\
object [Companion](index.md)

## Functions

| Name | Summary |
|---|---|
| [valueToEnum](value-to-enum.md) | [androidJvm]<br>@[JvmStatic](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.jvm/-jvm-static/index.html)<br>fun [valueToEnum](value-to-enum.md)(value: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)? = 1): [HardButton](../index.md) |
